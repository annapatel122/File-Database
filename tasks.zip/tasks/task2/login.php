<?php
// Read pass.txt file into an array
$passFile = fopen("pass.txt", "r") or die("Unable to open file!");
$passList = array();
while (!feof($passFile)) {
	$line = fgets($passFile);
	$line = trim($line);
	$passList[] = explode(":", $line);
}
fclose($passFile);

// Check if the username is present in the pass.txt file
$username = $_POST["username"];
$password = $_POST["password"];
$matchFound = false;
foreach ($passList as $pass) {
	if ($username == $pass[0]) {
		$matchFound = true;
		$hashedPassword = sha1($password);
		if ($hashedPassword == $pass[1]) {
			echo "Welcome, access has been granted!";
			exit;
		}
		else {
			echo "ERROR: Password is incorrect, sorry.";
			break;
		}
	}
}
if (!$matchFound) {
	echo "ERROR: Username not found, sorry.";
}
?>
<html>
<body>
	<form action="login.html">
		<button type="submit">Back</button>
	</form>
</body>
</html>
