<!DOCTYPE html>
<html>
<head>
</head>
<body>
<h2>Films</h2>
<button onclick="document.location='tasks.html'">Tasks</button>
<table border="1">
<thead>
<tr>
<th>Title</th>
<th>Description</th>
<th>Rental Duration</th>
<th>Rental Rate</th>
<th>Length</th>
<th>Special Features</th>
<th>Category</th>
</tr>
</thead>
<tbody>

<?php
include "config.php";
$sql="SELECT f.*, 
c.name AS category_name FROM film f 
JOIN film_category fc ON f.film_id = fc.film_id 
JOIN category c ON fc.category_id = c.category_id";
$result= $conn->query($sql);
while($row= mysqli_fetch_assoc($result))
{?>
<tr>
<td><?php echo $row['title'] ?></td>
<td><?php echo $row['description'] ?></td>
<td><?php echo $row['rental_duration'] ?></td>
<td><?php echo $row['rental_rate'] ?></td>
<td><?php echo $row['length'] ?></td>
<td><?php echo $row['special_features'] ?></td>
<td><?php echo $row['category_name'] ?></td>
</tr>
<?php }
?>

</tbody>
</table>
</body>
</html>
