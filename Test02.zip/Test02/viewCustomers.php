<!DOCTYPE html>
<html>
<head>
</head>
<body>
<h2>Customers</h2>
<button onclick="document.location='tasks.html'">Tasks</button>
<table border="1">
<thead>
<tr>
<th>First Name</th>
<th>Last Name</th>
<th>Email</th>
<th>Address</th>
<th>City</th>
<th>Postal Code</th>
<th>Amount</th>
</tr>
</thead>
<tbody>

<?php
include "config.php";

$sql= "SELECT c.customer_id, c.first_name, c.last_name, c.email, a.address, ci.city, a.postal_code, SUM(p.amount) AS amount
FROM customer c
JOIN address a ON c.address_id = a.address_id
JOIN city ci ON a.city_id = ci.city_id
JOIN payment p ON c.customer_id = p.customer_id
GROUP BY c.customer_id
ORDER BY c.last_name ASC;";
$result= $conn->query($sql);

while($row= $result->fetch_assoc())
{
?>
<tr>
<td><?php echo $row['first_name'] ?></td>
<td><?php echo $row['last_name'] ?></td>
<td><?php echo $row['email'] ?></td>
<td><?php echo $row['address'] ?></td>
<td><?php echo $row['city'] ?></td>
<td><?php echo $row['postal_code'] ?></td>
<td><?php echo $row['amount'] ?></td>
</tr>
<?php
}
?>

</tbody>
</table>
</body>
</html>