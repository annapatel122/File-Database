USE superstore;
SET AUTOCOMMIT=0;
SET FOREIGN_KEY_CHECKS=0;
SET GLOBAL FOREIGN_KEY_CHECKS=0;
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (1, '4751 Park Ave Dr', 'Chicago', 'IL', '45153');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (2, '2083 Park Ave Dr', 'Philadelphia', 'PA', '98478');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (3, '240 Elm St Blvd', 'Los Angeles', 'CA', '92405');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (4, '6496 Broadway Dr', 'New York', 'NY', '28522');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (5, '1822 Park Ave Blvd', 'Chicago', 'IL', '20350');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (6, '5800 Broadway Blvd', 'Philadelphia', 'PA', '90087');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (7, '5154 Elm St Blvd', 'Philadelphia', 'PA', '86459');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (8, '3778 5th Ave Dr', 'Chicago', 'IL', '32432');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (9, '5986 Elm St St', 'Philadelphia', 'PA', '44786');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (10, '8189 Main St Dr', 'New York', 'NY', '19329');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (11, '6585 5th Ave Ave', 'Los Angeles', 'CA', '95189');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (12, '4511 Main St Blvd', 'Los Angeles', 'CA', '84577');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (13, '5631 Broadway Blvd', 'Chicago', 'IL', '30296');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (14, '1520 5th Ave Ln', 'New York', 'NY', '93518');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (15, '8879 Elm St Dr', 'Houston', 'TX', '25015');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (16, '7500 Park Ave Ave', 'Houston', 'TX', '50373');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (17, '2045 Elm St Blvd', 'Los Angeles', 'CA', '83611');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (18, '7435 Elm St St', 'Chicago', 'IL', '23102');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (19, '8122 Park Ave Dr', 'Philadelphia', 'PA', '44822');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (20, '4391 5th Ave Dr', 'Los Angeles', 'CA', '40528');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (21, '4606 Broadway Dr', 'New York', 'NY', '71431');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (22, '9739 Main St St', 'Chicago', 'IL', '67437');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (23, '3879 Park Ave Ave', 'Los Angeles', 'CA', '73350');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (24, '2420 Elm St St', 'Chicago', 'IL', '51455');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (25, '437 5th Ave Blvd', 'Los Angeles', 'CA', '58135');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (26, '837 5th Ave St', 'Houston', 'TX', '66785');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (27, '3241 Elm St St', 'New York', 'NY', '91219');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (28, '6916 Main St Dr', 'New York', 'NY', '83836');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (29, '7732 5th Ave Ave', 'Chicago', 'IL', '79932');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (30, '3035 Elm St Blvd', 'Los Angeles', 'CA', '26404');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (31, '9924 5th Ave Ave', 'Philadelphia', 'PA', '24106');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (32, '7817 Park Ave Ln', 'Los Angeles', 'CA', '40434');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (33, '3808 Park Ave Ln', 'Houston', 'TX', '29158');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (34, '8906 Main St Ave', 'Philadelphia', 'PA', '46448');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (35, '2626 Park Ave St', 'Philadelphia', 'PA', '65435');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (36, '3423 5th Ave Dr', 'New York', 'NY', '65145');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (37, '6894 Park Ave Blvd', 'Philadelphia', 'PA', '88188');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (38, '4365 Elm St Ln', 'New York', 'NY', '75746');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (39, '890 Main St Ln', 'Philadelphia', 'PA', '11449');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (40, '4401 5th Ave Ln', 'Houston', 'TX', '45162');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (41, '3331 Elm St St', 'Chicago', 'IL', '24892');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (42, '1048 Broadway Blvd', 'Philadelphia', 'PA', '60233');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (43, '1866 Elm St St', 'Houston', 'TX', '67416');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (44, '7126 Park Ave St', 'Los Angeles', 'CA', '91093');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (45, '3084 Park Ave Ave', 'Chicago', 'IL', '43498');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (46, '6771 5th Ave Blvd', 'Los Angeles', 'CA', '23854');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (47, '2733 Elm St St', 'New York', 'NY', '53376');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (48, '8305 Elm St Blvd', 'New York', 'NY', '29510');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (49, '3693 Elm St Ln', 'New York', 'NY', '30480');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (50, '1001 Main St Ave', 'Houston', 'TX', '10256');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (51, '6510 5th Ave Ln', 'Philadelphia', 'PA', '21129');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (52, '4017 Main St Dr', 'Chicago', 'IL', '13282');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (53, '5038 5th Ave Ave', 'New York', 'NY', '27519');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (54, '1034 Elm St Ln', 'Chicago', 'IL', '56984');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (55, '9144 5th Ave St', 'New York', 'NY', '39522');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (56, '5168 Main St Ave', 'Houston', 'TX', '28546');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (57, '2702 5th Ave Dr', 'New York', 'NY', '14776');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (58, '9927 Main St Ave', 'New York', 'NY', '61658');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (59, '5947 5th Ave Dr', 'Philadelphia', 'PA', '31165');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (60, '6448 Park Ave Dr', 'New York', 'NY', '60571');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (61, '4748 Main St Ln', 'Houston', 'TX', '17943');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (62, '2266 Main St St', 'Los Angeles', 'CA', '91638');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (63, '5841 Elm St Blvd', 'Chicago', 'IL', '62225');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (64, '2345 Broadway Blvd', 'Chicago', 'IL', '92625');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (65, '6147 Main St Blvd', 'New York', 'NY', '54995');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (66, '5694 Broadway Dr', 'Los Angeles', 'CA', '49837');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (67, '1924 Elm St Dr', 'Philadelphia', 'PA', '77368');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (68, '6828 Park Ave Ave', 'New York', 'NY', '72134');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (69, '3987 Main St St', 'New York', 'NY', '59381');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (70, '7835 Elm St Dr', 'Houston', 'TX', '48933');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (71, '7782 Park Ave St', 'Chicago', 'IL', '63501');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (72, '6144 Broadway St', 'Los Angeles', 'CA', '63737');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (73, '8885 Elm St Ave', 'Los Angeles', 'CA', '84856');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (74, '4431 Main St St', 'Philadelphia', 'PA', '31441');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (75, '8883 Main St Dr', 'New York', 'NY', '11531');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (76, '3097 Main St Blvd', 'Chicago', 'IL', '35920');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (77, '5960 Park Ave Ln', 'New York', 'NY', '51348');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (78, '1865 Main St St', 'Chicago', 'IL', '35795');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (79, '4218 Broadway Dr', 'Houston', 'TX', '59039');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (80, '7842 5th Ave Dr', 'Los Angeles', 'CA', '65113');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (81, '4616 Elm St Ave', 'Philadelphia', 'PA', '81983');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (82, '8930 5th Ave Blvd', 'Houston', 'TX', '70501');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (83, '3725 Park Ave Ln', 'New York', 'NY', '66898');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (84, '3946 Main St Blvd', 'New York', 'NY', '32391');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (85, '8252 Broadway St', 'Philadelphia', 'PA', '66474');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (86, '9409 Park Ave Blvd', 'Philadelphia', 'PA', '40819');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (87, '269 Main St Ln', 'New York', 'NY', '62044');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (88, '9661 Park Ave Ln', 'Houston', 'TX', '16389');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (89, '8728 Park Ave St', 'Chicago', 'IL', '86030');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (90, '3814 Broadway Blvd', 'Houston', 'TX', '51448');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (91, '7720 5th Ave Blvd', 'Chicago', 'IL', '44653');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (92, '6400 Elm St Dr', 'Philadelphia', 'PA', '27722');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (93, '8836 Elm St St', 'Houston', 'TX', '38630');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (94, '9092 5th Ave Ave', 'Chicago', 'IL', '57958');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (95, '3703 5th Ave Ln', 'Philadelphia', 'PA', '91930');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (96, '1496 5th Ave Blvd', 'Chicago', 'IL', '77638');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (97, '9916 Main St Ave', 'Houston', 'TX', '40000');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (98, '5288 Main St Ave', 'Houston', 'TX', '37303');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (99, '4355 5th Ave Blvd', 'Los Angeles', 'CA', '87908');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (100, '5390 Park Ave St', 'New York', 'NY', '64965');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (101, '4002 Park Ave St', 'Chicago', 'IL', '36670');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (102, '372 Main St Blvd', 'Los Angeles', 'CA', '21945');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (103, '4322 Broadway Ln', 'Los Angeles', 'CA', '42719');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (104, '7995 Broadway Dr', 'New York', 'NY', '24367');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (105, '958 Main St St', 'Houston', 'TX', '67467');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (106, '4568 Main St Dr', 'Philadelphia', 'PA', '76882');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (107, '380 Elm St St', 'New York', 'NY', '43105');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (108, '2172 Main St Blvd', 'Los Angeles', 'CA', '72225');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (109, '8267 5th Ave Ave', 'Philadelphia', 'PA', '54707');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (110, '3731 5th Ave Ln', 'New York', 'NY', '67166');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (111, '6557 Elm St Ln', 'Chicago', 'IL', '86763');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (112, '4790 Main St Ln', 'Los Angeles', 'CA', '26298');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (113, '9658 Main St Ave', 'Houston', 'TX', '15719');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (114, '4812 5th Ave Dr', 'Los Angeles', 'CA', '25193');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (115, '519 Main St Dr', 'Houston', 'TX', '74923');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (116, '3760 Park Ave Ln', 'Chicago', 'IL', '62705');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (117, '8852 Park Ave Dr', 'Houston', 'TX', '80923');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (118, '3777 Elm St Ln', 'Los Angeles', 'CA', '90190');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (119, '1072 Main St St', 'Los Angeles', 'CA', '91834');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (120, '851 Broadway Ln', 'Los Angeles', 'CA', '87207');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (121, '3935 Main St Blvd', 'Houston', 'TX', '10842');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (122, '1004 Main St St', 'Philadelphia', 'PA', '37018');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (123, '7763 5th Ave Blvd', 'Los Angeles', 'CA', '22459');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (124, '1631 Elm St St', 'Los Angeles', 'CA', '14157');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (125, '2303 Main St Dr', 'Chicago', 'IL', '89587');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (126, '1754 Elm St Blvd', 'Los Angeles', 'CA', '58296');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (127, '543 5th Ave Ln', 'Chicago', 'IL', '15960');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (128, '8029 Main St St', 'Chicago', 'IL', '32390');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (129, '4528 Main St St', 'Los Angeles', 'CA', '15614');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (130, '1924 5th Ave Ln', 'Houston', 'TX', '57754');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (131, '3778 Main St St', 'Los Angeles', 'CA', '17605');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (132, '2971 5th Ave St', 'Philadelphia', 'PA', '34525');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (133, '3750 Broadway Dr', 'New York', 'NY', '74651');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (134, '9338 Elm St St', 'New York', 'NY', '59087');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (135, '9405 5th Ave Dr', 'Houston', 'TX', '27383');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (136, '2235 Main St Ave', 'Philadelphia', 'PA', '56368');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (137, '6283 5th Ave Ln', 'Chicago', 'IL', '47312');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (138, '169 5th Ave St', 'Houston', 'TX', '26095');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (139, '1851 Elm St Dr', 'Houston', 'TX', '26998');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (140, '5219 Park Ave Ave', 'Houston', 'TX', '93318');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (141, '3392 Main St Ave', 'Chicago', 'IL', '91771');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (142, '3388 Park Ave Ave', 'Philadelphia', 'PA', '25529');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (143, '5204 5th Ave St', 'New York', 'NY', '31395');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (144, '4533 Broadway St', 'Chicago', 'IL', '89809');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (145, '6278 5th Ave Ln', 'Houston', 'TX', '65769');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (146, '6315 Main St Blvd', 'Chicago', 'IL', '99329');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (147, '4278 Elm St St', 'Los Angeles', 'CA', '59222');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (148, '8569 5th Ave St', 'New York', 'NY', '86891');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (149, '4253 Park Ave Dr', 'Chicago', 'IL', '96403');
INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             (150, '3069 Park Ave Dr', 'Chicago', 'IL', '25453');
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('5747881', 'Mike', 'Rodriguez', 'customer1@superstore.com', '(861) 621-8068', 23);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('4613382', 'Sarah', 'Miller', 'customer2@superstore.com', '(639) 810-4704', 41);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('9567283', 'John', 'Jones', 'customer3@superstore.com', '(769) 451-6793', 66);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('1191804', 'John', 'Garcia', 'customer4@superstore.com', '(443) 995-3335', 129);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('5420875', 'Lisa', 'Martinez', 'customer5@superstore.com', '(371) 323-4073', 149);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('3358546', 'Sarah', 'Brown', 'customer6@superstore.com', '(875) 767-7487', 53);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('4636697', 'Emily', 'Johnson', 'customer7@superstore.com', '(104) 958-6433', 21);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('1060178', 'John', 'Jones', 'customer8@superstore.com', '(645) 444-5653', 26);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('3817249', 'Steven', 'Miller', 'customer9@superstore.com', '(084) 043-2362', 113);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('79871710', 'Mary', 'Smith', 'customer10@superstore.com', '(800) 437-1232', 69);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('86887311', 'Lisa', 'Jones', 'customer11@superstore.com', '(358) 613-4184', 21);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('55441812', 'Mark', 'Garcia', 'customer12@superstore.com', '(192) 819-0708', 112);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('19176813', 'Sarah', 'Martinez', 'customer13@superstore.com', '(986) 294-6157', 79);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('44817314', 'Lisa', 'Miller', 'customer14@superstore.com', '(644) 050-5324', 28);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('45211015', 'Emily', 'Jones', 'customer15@superstore.com', '(209) 032-9233', 22);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('73876616', 'John', 'Johnson', 'customer16@superstore.com', '(988) 395-8919', 107);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('90404117', 'David', 'Garcia', 'customer17@superstore.com', '(424) 923-2610', 149);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('26184318', 'Emily', 'Garcia', 'customer18@superstore.com', '(654) 185-2184', 150);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('60434319', 'Sarah', 'Johnson', 'customer19@superstore.com', '(934) 644-6589', 9);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('90574720', 'Mark', 'Williams', 'customer20@superstore.com', '(895) 933-2592', 61);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('60620321', 'Sarah', 'Johnson', 'customer21@superstore.com', '(174) 913-0122', 90);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('63506722', 'Steven', 'Rodriguez', 'customer22@superstore.com', '(987) 380-2204', 87);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('35939823', 'Emily', 'Rodriguez', 'customer23@superstore.com', '(543) 319-5297', 79);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('17216524', 'Lisa', 'Johnson', 'customer24@superstore.com', '(652) 798-3284', 65);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('19957625', 'Lisa', 'Rodriguez', 'customer25@superstore.com', '(439) 654-0088', 26);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('72791026', 'Mary', 'Johnson', 'customer26@superstore.com', '(355) 524-4809', 135);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('79727727', 'Mark', 'Brown', 'customer27@superstore.com', '(832) 010-8302', 17);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('97166128', 'John', 'Garcia', 'customer28@superstore.com', '(663) 974-5894', 69);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('42934029', 'Sarah', 'Martinez', 'customer29@superstore.com', '(086) 030-5575', 43);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('52857730', 'Emily', 'Martinez', 'customer30@superstore.com', '(814) 617-2537', 39);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('31089931', 'Linda', 'Garcia', 'customer31@superstore.com', '(734) 806-6055', 37);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('66891532', 'Mark', 'Miller', 'customer32@superstore.com', '(824) 031-6981', 123);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('30020833', 'Mike', 'Miller', 'customer33@superstore.com', '(023) 639-1764', 128);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('35819334', 'Sarah', 'Jones', 'customer34@superstore.com', '(311) 050-0901', 63);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('98648035', 'John', 'Smith', 'customer35@superstore.com', '(685) 193-1454', 1);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('33135036', 'Mark', 'Smith', 'customer36@superstore.com', '(790) 450-8008', 29);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('31041937', 'Mark', 'Jones', 'customer37@superstore.com', '(667) 765-4644', 111);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('65735838', 'Linda', 'Miller', 'customer38@superstore.com', '(541) 688-5451', 71);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('51685139', 'John', 'Davis', 'customer39@superstore.com', '(194) 593-1129', 89);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('68958240', 'Mary', 'Smith', 'customer40@superstore.com', '(145) 291-6337', 65);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('18479241', 'Steven', 'Brown', 'customer41@superstore.com', '(200) 657-4513', 149);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('16914942', 'Mike', 'Smith', 'customer42@superstore.com', '(862) 291-8416', 5);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('41535543', 'Mike', 'Williams', 'customer43@superstore.com', '(990) 156-4137', 10);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('61888244', 'Sarah', 'Williams', 'customer44@superstore.com', '(228) 441-7644', 59);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('48126845', 'Mike', 'Williams', 'customer45@superstore.com', '(096) 703-0230', 103);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('10699346', 'Linda', 'Martinez', 'customer46@superstore.com', '(153) 616-9844', 61);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('13340547', 'Lisa', 'Miller', 'customer47@superstore.com', '(193) 645-3592', 13);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('17921848', 'Mary', 'Williams', 'customer48@superstore.com', '(518) 222-0449', 85);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('66762349', 'Sarah', 'Williams', 'customer49@superstore.com', '(490) 514-7083', 8);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('24754850', 'Linda', 'Johnson', 'customer50@superstore.com', '(415) 044-7717', 148);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('72134251', 'David', 'Williams', 'customer51@superstore.com', '(593) 686-3056', 114);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('41631552', 'Mary', 'Williams', 'customer52@superstore.com', '(492) 432-6518', 127);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('29120853', 'Mike', 'Rodriguez', 'customer53@superstore.com', '(419) 820-3751', 16);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('45662354', 'Mary', 'Martinez', 'customer54@superstore.com', '(128) 823-8808', 75);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('57760855', 'Lisa', 'Garcia', 'customer55@superstore.com', '(300) 865-6883', 32);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('27621156', 'Steven', 'Garcia', 'customer56@superstore.com', '(662) 704-5192', 143);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('41178957', 'Lisa', 'Brown', 'customer57@superstore.com', '(008) 618-5659', 127);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('69346758', 'John', 'Brown', 'customer58@superstore.com', '(128) 698-3081', 85);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('13059159', 'John', 'Garcia', 'customer59@superstore.com', '(810) 439-3911', 42);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('61704960', 'Mary', 'Jones', 'customer60@superstore.com', '(629) 212-3818', 132);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('72206261', 'Lisa', 'Johnson', 'customer61@superstore.com', '(414) 887-1566', 51);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('76414462', 'David', 'Brown', 'customer62@superstore.com', '(838) 727-6206', 144);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('88261663', 'Emily', 'Johnson', 'customer63@superstore.com', '(327) 047-7332', 3);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('18218864', 'Lisa', 'Williams', 'customer64@superstore.com', '(522) 420-8894', 149);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('47088865', 'John', 'Smith', 'customer65@superstore.com', '(963) 572-8551', 33);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('77008666', 'Lisa', 'Smith', 'customer66@superstore.com', '(645) 260-7999', 18);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('98053067', 'Mary', 'Martinez', 'customer67@superstore.com', '(495) 819-5064', 88);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('84155268', 'John', 'Davis', 'customer68@superstore.com', '(043) 579-3804', 74);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('94375369', 'Mark', 'Miller', 'customer69@superstore.com', '(468) 655-8806', 1);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('42034870', 'Mary', 'Miller', 'customer70@superstore.com', '(872) 907-7032', 146);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('29008071', 'David', 'Williams', 'customer71@superstore.com', '(793) 421-9149', 118);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('51259672', 'David', 'Jones', 'customer72@superstore.com', '(106) 129-1923', 101);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('63779073', 'Mark', 'Martinez', 'customer73@superstore.com', '(188) 336-9712', 12);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('74106074', 'Mark', 'Johnson', 'customer74@superstore.com', '(137) 453-9891', 22);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('95705075', 'Linda', 'Brown', 'customer75@superstore.com', '(558) 122-7059', 114);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('36424376', 'Mark', 'Smith', 'customer76@superstore.com', '(676) 639-4612', 110);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('28247677', 'Mike', 'Jones', 'customer77@superstore.com', '(107) 133-3863', 72);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('66808778', 'Steven', 'Davis', 'customer78@superstore.com', '(797) 897-4522', 122);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('12981179', 'Mary', 'Brown', 'customer79@superstore.com', '(785) 787-5945', 128);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('52789380', 'Steven', 'Brown', 'customer80@superstore.com', '(752) 809-8383', 47);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('47202181', 'Mary', 'Davis', 'customer81@superstore.com', '(842) 900-3846', 52);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('11574382', 'Mark', 'Williams', 'customer82@superstore.com', '(162) 575-7282', 8);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('29678183', 'David', 'Smith', 'customer83@superstore.com', '(320) 942-8037', 136);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('22161984', 'Lisa', 'Martinez', 'customer84@superstore.com', '(769) 661-6303', 98);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('26184785', 'Lisa', 'Brown', 'customer85@superstore.com', '(853) 428-3316', 125);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('81547586', 'Emily', 'Smith', 'customer86@superstore.com', '(411) 925-6628', 6);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('39907387', 'Sarah', 'Rodriguez', 'customer87@superstore.com', '(807) 228-8049', 116);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('15913788', 'John', 'Johnson', 'customer88@superstore.com', '(981) 977-0637', 82);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('79905889', 'Mike', 'Davis', 'customer89@superstore.com', '(871) 724-5017', 33);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('57375690', 'Emily', 'Johnson', 'customer90@superstore.com', '(511) 809-7810', 142);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('65545891', 'David', 'Johnson', 'customer91@superstore.com', '(594) 691-5095', 5);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('50035592', 'John', 'Jones', 'customer92@superstore.com', '(726) 465-7082', 67);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('17136193', 'Mary', 'Johnson', 'customer93@superstore.com', '(728) 715-8537', 134);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('60893194', 'Mark', 'Davis', 'customer94@superstore.com', '(088) 515-4071', 45);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('59194695', 'Mary', 'Williams', 'customer95@superstore.com', '(645) 798-2404', 119);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('88214496', 'Mark', 'Miller', 'customer96@superstore.com', '(985) 683-2448', 110);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('18026397', 'Mark', 'Garcia', 'customer97@superstore.com', '(089) 916-3291', 70);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('31818198', 'Lisa', 'Rodriguez', 'customer98@superstore.com', '(470) 192-3800', 110);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('54791899', 'Emily', 'Martinez', 'customer99@superstore.com', '(974) 109-2805', 90);
INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('461997100', 'Mike', 'Martinez', 'customer100@superstore.com', '(109) 497-8247', 116);
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('428188', '9466', '41');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('273847', '7044', '124');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('689886', '1868', '91');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('530256', '6527', '57');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('202058', '6241', '147');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('427382', '9249', '136');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('930665', '1532', '144');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('348857', '3339', '85');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('849175', '8701', '47');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('233432', '5736', '57');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('271506', '8416', '70');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('798672', '2636', '84');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('254098', '9336', '150');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('783231', '8179', '122');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('681599', '2987', '77');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('454740', '7739', '102');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('329740', '2734', '51');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('578724', '8148', '46');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('765948', '2266', '28');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('614074', '4123', '110');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('296262', '8332', '146');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('382658', '8432', '6');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('287531', '5763', '62');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('747556', '6140', '117');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('584484', '3902', '135');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('343998', '2202', '85');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('712729', '8030', '89');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('212596', '1162', '7');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('836235', '5697', '129');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('895599', '6232', '26');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('920320', '5404', '94');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('576485', '5600', '37');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('522794', '7590', '54');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('917287', '7906', '8');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('716539', '4161', '46');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('878516', '9117', '28');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('611984', '9853', '42');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('154150', '8608', '45');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('497250', '1002', '48');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('829956', '2138', '76');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('840283', '5466', '54');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('123907', '3830', '36');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('107433', '6874', '20');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('651433', '9795', '61');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('503252', '3695', '121');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('636270', '9959', '93');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('562865', '4242', '147');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('499937', '3272', '30');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('510820', '1924', '81');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('333719', '1015', '27');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('169587', '3857', '54');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('520103', '7922', '27');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('353344', '6694', '10');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('191574', '4105', '139');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('317390', '2560', '39');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('442333', '5500', '143');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('665171', '6947', '131');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('840921', '2941', '39');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('393610', '8221', '117');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('801457', '4837', '17');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('118516', '8894', '11');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('885131', '1403', '112');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('502951', '4654', '41');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('603176', '9905', '133');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('726333', '5062', '76');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('630741', '3231', '103');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('348391', '7819', '115');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('420809', '7240', '130');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('147824', '7067', '1');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('370051', '6171', '80');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('618594', '3534', '101');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('606853', '4219', '114');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('189992', '1436', '36');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('708196', '2845', '75');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('117562', '6404', '123');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('878080', '7535', '46');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('578293', '8638', '91');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('635642', '8463', '19');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('969008', '7263', '74');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('402392', '9623', '51');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('779221', '9085', '118');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('684036', '7118', '113');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('220289', '4325', '137');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('371477', '6453', '57');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('310924', '1935', '134');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('740074', '8165', '65');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('507926', '2075', '12');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('278327', '2320', '75');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('191643', '5884', '67');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('816464', '8914', '85');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('772657', '7811', '39');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('789448', '2412', '146');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('942159', '1816', '137');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('705374', '5021', '105');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('762075', '2521', '74');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('545039', '6497', '128');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('249956', '2042', '101');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('704400', '6051', '78');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('203935', '8054', '62');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('313083', '1082', '69');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('432968', '2975', '20');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('738279', '3037', '75');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('381293', '8327', '27');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('531847', '5238', '18');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('920023', '7240', '141');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('371725', '2192', '32');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('226021', '2335', '66');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('616724', '6713', '80');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('520985', '9924', '105');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('557888', '4840', '58');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('797705', '4494', '20');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('624576', '7674', '1');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('101706', '5767', '54');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('171327', '4670', '110');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('275811', '9959', '1');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('480645', '6988', '34');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('925338', '9003', '133');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('803798', '8731', '57');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('331381', '2035', '76');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('552590', '5006', '131');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('472445', '5462', '34');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('641755', '7615', '143');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('286550', '6068', '106');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('980270', '5147', '107');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('145872', '7818', '145');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('700483', '3930', '31');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('300968', '7581', '22');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('390945', '7964', '42');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('315540', '2122', '143');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('364589', '8514', '19');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('107455', '5969', '18');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('503004', '5562', '25');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('701852', '8765', '74');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('186433', '4620', '64');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('971771', '8838', '23');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('945683', '7912', '6');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('119796', '6131', '38');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('422065', '3013', '23');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('621622', '8790', '12');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('433503', '8623', '137');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('146974', '6741', '83');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('376718', '4943', '5');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('420276', '4646', '68');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('409709', '1036', '76');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('631638', '8555', '109');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('778363', '2262', '39');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('207003', '2977', '124');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('179455', '7812', '143');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('282490', '3453', '90');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('702671', '7806', '3');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('574091', '1156', '138');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('379291', '1806', '107');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('858585', '6137', '129');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('685492', '1931', '39');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('808068', '5479', '7');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('342388', '9707', '102');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('173939', '6917', '138');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('270564', '7436', '39');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('934264', '9421', '140');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('290413', '8749', '134');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('229651', '4152', '52');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('445022', '7709', '14');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('345959', '4829', '5');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('749207', '7678', '66');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('385824', '3384', '21');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('281276', '9296', '86');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('855756', '2907', '100');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('874209', '3847', '88');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('347308', '9124', '72');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('820842', '7035', '80');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('309178', '9772', '136');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('643064', '2341', '44');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('227992', '9110', '101');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('741857', '9784', '118');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('931797', '1377', '66');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('609731', '6601', '7');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('503431', '5533', '114');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('747530', '3012', '117');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('110140', '1490', '150');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('175392', '3014', '67');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('793482', '2047', '122');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('550539', '2602', '40');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('782312', '8477', '137');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('860911', '6536', '27');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('775562', '4705', '131');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('926292', '3946', '20');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('981054', '7196', '72');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('766911', '2238', '9');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('223633', '1612', '82');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('814164', '7604', '46');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('771962', '3366', '109');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('276644', '4302', '65');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('985976', '9590', '36');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('761112', '4993', '112');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('394921', '4713', '31');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('562402', '1293', '9');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('111951', '5021', '57');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('492338', '8905', '82');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('202666', '6932', '115');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('429579', '9903', '104');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('407855', '2130', '140');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('641234', '7015', '141');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('767012', '4977', '44');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('786902', '2760', '59');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('734127', '4130', '91');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('630232', '8006', '56');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('879455', '8416', '123');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('289848', '9776', '37');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('898600', '5913', '108');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('689638', '1311', '120');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('421236', '9210', '146');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('565258', '6374', '25');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('634897', '3336', '13');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('244100', '9189', '140');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('884635', '1634', '35');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('257410', '3615', '133');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('252805', '7668', '83');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('257591', '7227', '139');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('107726', '2994', '96');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('522263', '1256', '144');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('877395', '4895', '148');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('948931', '1427', '19');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('737189', '3861', '18');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('239990', '4828', '143');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('817337', '7450', '21');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('249650', '7456', '93');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('997478', '8818', '120');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('418080', '2877', '135');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('770113', '6914', '14');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('134403', '8817', '140');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('346969', '2532', '132');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('147850', '4183', '59');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('283289', '5080', '57');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('629819', '1760', '68');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('746339', '1696', '106');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('187034', '1524', '115');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('171383', '2394', '15');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('156403', '9357', '1');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('430182', '8400', '141');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('878557', '1460', '67');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('157058', '3124', '109');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('167775', '1625', '68');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('814250', '6176', '108');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('949700', '3235', '114');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('798618', '9553', '149');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('785077', '6331', '148');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('252556', '5705', '45');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('284839', '4099', '12');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('310614', '2274', '10');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('418152', '8015', '5');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('289426', '2574', '87');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('490255', '1924', '150');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('274700', '5885', '62');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('859261', '6535', '17');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('846923', '1822', '55');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('680706', '1572', '25');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('134808', '4907', '72');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('577096', '6199', '30');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('396921', '9369', '103');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('877875', '3448', '104');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('684437', '8353', '57');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('309241', '4173', '141');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('553532', '4764', '81');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('988656', '2960', '68');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('678195', '4869', '12');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('379703', '2021', '21');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('255891', '6146', '113');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('909618', '1660', '14');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('623189', '7740', '110');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('657376', '5264', '23');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('467194', '8586', '36');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('569841', '5467', '67');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('446761', '1113', '88');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('168264', '5922', '14');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('210283', '7294', '28');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('187880', '5441', '91');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('120175', '2491', '125');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('141624', '5352', '74');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('183626', '4223', '125');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('832848', '8799', '116');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('482615', '6362', '104');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('973297', '2248', '139');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('614227', '9714', '67');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('311661', '2335', '35');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('306156', '4732', '5');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('706401', '2426', '79');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('713693', '9660', '19');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('789188', '8453', '84');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('456438', '3259', '117');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('493506', '1957', '94');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('127006', '3531', '122');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('478356', '7827', '145');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('723172', '7080', '141');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('771702', '8427', '145');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('912020', '7546', '118');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('483283', '4646', '73');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('309690', '2781', '80');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('172459', '4331', '13');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('221714', '9673', '91');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('543329', '4163', '17');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('165157', '7809', '82');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('804279', '5325', '106');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('982547', '4849', '100');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('482489', '8886', '21');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('309542', '3551', '57');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('955929', '2081', '140');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('595416', '3172', '86');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('658235', '7690', '50');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('378402', '6246', '143');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('225507', '5567', '72');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('292150', '9016', '39');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('557059', '4677', '30');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('144444', '2489', '38');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('639121', '3269', '124');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('531573', '2504', '106');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('568793', '1846', '122');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('197189', '1853', '108');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('981414', '5580', '56');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('944532', '3537', '90');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('994515', '6246', '118');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('815077', '8723', '12');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('769143', '8723', '48');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('491608', '5086', '119');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('416413', '9090', '32');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('663274', '2334', '126');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('971386', '1758', '49');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('920949', '5818', '136');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('301943', '8901', '95');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('585876', '5713', '94');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('134072', '6644', '134');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('670607', '4938', '144');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('255837', '5678', '56');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('926427', '6739', '6');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('755154', '4089', '31');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('697546', '6425', '9');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('151289', '4323', '63');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('138707', '1988', '80');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('313577', '5805', '42');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('390559', '9519', '31');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('378323', '6626', '143');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('733507', '3176', '103');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('678287', '1601', '121');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('950253', '8991', '1');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('148090', '4076', '21');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('901041', '7209', '62');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('839381', '2668', '78');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('848672', '5891', '140');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('688687', '1062', '52');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('443886', '5997', '37');
INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('602697', '1681', '145');
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 1, 'laptop', 'A brilliant laptop in an magnificent blue made of wood useful for writing', 459, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 1
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 2, 'table', 'A fantastic table in an gorgeous blue made of metal useful for painting', 351, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 2
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 3, 'laptop', 'A fantastic laptop in an gorgeous purple made of plastic useful for writing', 398, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 3
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 4, 'book', 'A fantastic book in an splendid yellow made of ceramic useful for drilling', 259, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 4
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 5, 'table', 'A fantastic table in an splendid red made of plastic useful for writing', 308, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 5
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 6, 'hammer', 'A brilliant hammer in an splendid blue made of ceramic useful for cooking', 495, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 6
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 7, 'table', 'A amazing table in an magnificent yellow made of metal useful for painting', 344, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 7
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 8, 'laptop', 'A fantastic laptop in an stunning green made of ceramic useful for cooking', 244, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 8
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 9, 'table', 'A brilliant table in an magnificent green made of wood useful for cooking', 221, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 9
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 10, 'laptop', 'A wonderful laptop in an splendid blue made of metal useful for writing', 107, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 10
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 11, 'book', 'A wonderful book in an splendid yellow made of wood useful for painting', 335, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 11
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 12, 'table', 'A spectacular table in an illustrious red made of plastic useful for painting', 56, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 12
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 13, 'book', 'A brilliant book in an stunning green made of ceramic useful for painting', 252, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 13
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 14, 'table', 'A wonderful table in an stunning purple made of plastic useful for painting', 184, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 14
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 15, 'hammer', 'A wonderful hammer in an illustrious red made of plastic useful for writing', 249, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 15
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 16, 'laptop', 'A fantastic laptop in an splendid yellow made of ceramic useful for painting', 276, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 16
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 17, 'hammer', 'A wonderful hammer in an magnificent purple made of glass useful for writing', 316, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 17
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 18, 'laptop', 'A wonderful laptop in an magnificent purple made of glass useful for writing', 485, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 18
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 19, 'hammer', 'A amazing hammer in an illustrious red made of plastic useful for drilling', 201, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 19
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 20, 'chair', 'A amazing chair in an illustrious yellow made of glass useful for cooking', 96, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 20
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 21, 'laptop', 'A spectacular laptop in an splendid purple made of metal useful for writing', 320, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 21
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 22, 'book', 'A brilliant book in an splendid blue made of plastic useful for drilling', 147, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 22
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 23, 'laptop', 'A spectacular laptop in an magnificent red made of plastic useful for drilling', 252, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 23
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 24, 'hammer', 'A spectacular hammer in an stunning blue made of plastic useful for painting', 413, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 24
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 25, 'laptop', 'A amazing laptop in an stunning red made of wood useful for drilling', 39, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 25
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 26, 'book', 'A spectacular book in an stunning red made of ceramic useful for drilling', 394, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 26
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 27, 'chair', 'A brilliant chair in an stunning green made of glass useful for cutting', 350, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 27
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 28, 'chair', 'A spectacular chair in an stunning green made of ceramic useful for drilling', 461, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 28
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 29, 'book', 'A spectacular book in an illustrious blue made of metal useful for cutting', 227, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 29
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 30, 'hammer', 'A spectacular hammer in an magnificent green made of plastic useful for drilling', 128, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 30
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 31, 'chair', 'A fantastic chair in an gorgeous red made of metal useful for drilling', 337, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 31
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 32, 'laptop', 'A brilliant laptop in an illustrious blue made of wood useful for writing', 277, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 32
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 33, 'book', 'A spectacular book in an magnificent blue made of wood useful for drilling', 379, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 33
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 34, 'book', 'A brilliant book in an gorgeous green made of ceramic useful for painting', 467, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 34
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 35, 'chair', 'A amazing chair in an splendid blue made of metal useful for cooking', 45, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 35
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 36, 'laptop', 'A spectacular laptop in an stunning green made of wood useful for writing', 182, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 36
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 37, 'book', 'A wonderful book in an gorgeous yellow made of glass useful for painting', 208, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 37
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 38, 'book', 'A brilliant book in an stunning yellow made of wood useful for cutting', 167, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 38
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 39, 'hammer', 'A fantastic hammer in an magnificent purple made of metal useful for drilling', 127, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 39
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 40, 'table', 'A spectacular table in an magnificent yellow made of metal useful for cooking', 131, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 40
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 41, 'table', 'A brilliant table in an magnificent blue made of glass useful for cutting', 213, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 41
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 42, 'chair', 'A brilliant chair in an stunning red made of wood useful for cutting', 457, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 42
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 43, 'chair', 'A wonderful chair in an splendid red made of glass useful for cutting', 169, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 43
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 44, 'book', 'A amazing book in an gorgeous blue made of wood useful for cutting', 408, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 44
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 45, 'chair', 'A spectacular chair in an illustrious green made of plastic useful for cooking', 250, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 45
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 46, 'table', 'A brilliant table in an splendid yellow made of metal useful for writing', 114, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 46
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 47, 'book', 'A amazing book in an magnificent red made of plastic useful for painting', 133, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 47
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 48, 'book', 'A fantastic book in an illustrious red made of wood useful for drilling', 230, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 48
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 49, 'laptop', 'A amazing laptop in an splendid purple made of plastic useful for cooking', 94, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 49
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 50, 'table', 'A wonderful table in an illustrious red made of wood useful for writing', 463, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 50
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 51, 'table', 'A amazing table in an gorgeous blue made of glass useful for cutting', 74, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 51
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 52, 'hammer', 'A wonderful hammer in an illustrious red made of plastic useful for writing', 243, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 52
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 53, 'chair', 'A fantastic chair in an illustrious red made of plastic useful for cutting', 258, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 53
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 54, 'chair', 'A brilliant chair in an gorgeous green made of wood useful for cutting', 329, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 54
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 55, 'hammer', 'A brilliant hammer in an illustrious yellow made of metal useful for cooking', 196, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 55
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 56, 'laptop', 'A spectacular laptop in an illustrious red made of metal useful for cutting', 347, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 56
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 57, 'chair', 'A spectacular chair in an magnificent blue made of glass useful for cooking', 88, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 57
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 58, 'chair', 'A brilliant chair in an gorgeous yellow made of ceramic useful for cooking', 154, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 58
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 59, 'hammer', 'A wonderful hammer in an splendid yellow made of plastic useful for cutting', 324, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 59
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 60, 'table', 'A amazing table in an illustrious green made of ceramic useful for drilling', 142, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 60
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 61, 'chair', 'A wonderful chair in an stunning yellow made of wood useful for cooking', 431, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 61
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 62, 'book', 'A wonderful book in an stunning yellow made of metal useful for painting', 338, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 62
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 63, 'laptop', 'A amazing laptop in an gorgeous yellow made of glass useful for drilling', 303, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 63
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 64, 'laptop', 'A brilliant laptop in an stunning blue made of metal useful for writing', 66, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 64
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 65, 'laptop', 'A wonderful laptop in an gorgeous yellow made of wood useful for cutting', 40, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 65
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 66, 'chair', 'A fantastic chair in an magnificent red made of plastic useful for writing', 110, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 66
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 67, 'book', 'A brilliant book in an magnificent green made of wood useful for painting', 80, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 67
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 68, 'book', 'A fantastic book in an stunning red made of glass useful for writing', 318, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 68
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 69, 'chair', 'A wonderful chair in an magnificent red made of ceramic useful for painting', 422, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 69
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 70, 'book', 'A amazing book in an magnificent blue made of glass useful for cutting', 276, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 70
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 71, 'laptop', 'A brilliant laptop in an stunning red made of ceramic useful for drilling', 390, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 71
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 72, 'table', 'A amazing table in an gorgeous green made of wood useful for cutting', 458, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 72
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 73, 'chair', 'A spectacular chair in an magnificent red made of metal useful for cutting', 301, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 73
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 74, 'chair', 'A spectacular chair in an illustrious red made of ceramic useful for cutting', 293, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 74
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 75, 'book', 'A brilliant book in an gorgeous purple made of plastic useful for drilling', 45, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 75
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 76, 'hammer', 'A wonderful hammer in an magnificent purple made of plastic useful for cutting', 329, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 76
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 77, 'book', 'A fantastic book in an magnificent green made of wood useful for cutting', 223, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 77
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 78, 'hammer', 'A amazing hammer in an magnificent blue made of glass useful for drilling', 92, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 78
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 79, 'hammer', 'A amazing hammer in an splendid blue made of ceramic useful for drilling', 256, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 79
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 80, 'book', 'A amazing book in an gorgeous red made of ceramic useful for drilling', 149, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 80
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 81, 'book', 'A amazing book in an stunning green made of metal useful for writing', 468, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 81
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 82, 'laptop', 'A spectacular laptop in an splendid blue made of metal useful for drilling', 275, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 82
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 83, 'table', 'A spectacular table in an splendid red made of glass useful for writing', 159, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 83
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 84, 'book', 'A spectacular book in an gorgeous blue made of metal useful for writing', 187, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 84
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 85, 'chair', 'A amazing chair in an gorgeous red made of ceramic useful for painting', 22, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 85
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 86, 'hammer', 'A spectacular hammer in an illustrious purple made of ceramic useful for cooking', 144, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 86
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 87, 'laptop', 'A fantastic laptop in an illustrious purple made of glass useful for painting', 378, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 87
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 88, 'hammer', 'A amazing hammer in an stunning red made of metal useful for cooking', 152, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 88
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 89, 'chair', 'A wonderful chair in an stunning red made of metal useful for cooking', 96, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 89
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 90, 'book', 'A brilliant book in an stunning red made of plastic useful for writing', 490, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 90
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 91, 'hammer', 'A wonderful hammer in an magnificent yellow made of ceramic useful for writing', 332, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 91
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 92, 'table', 'A wonderful table in an illustrious purple made of ceramic useful for cutting', 490, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 92
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 93, 'table', 'A spectacular table in an gorgeous blue made of wood useful for painting', 178, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 93
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 94, 'laptop', 'A spectacular laptop in an gorgeous blue made of plastic useful for painting', 214, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 94
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 95, 'laptop', 'A wonderful laptop in an magnificent green made of glass useful for writing', 449, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 95
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 96, 'laptop', 'A wonderful laptop in an stunning green made of glass useful for cutting', 53, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 96
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 97, 'table', 'A spectacular table in an gorgeous green made of plastic useful for cutting', 394, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 97
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 98, 'book', 'A wonderful book in an illustrious red made of ceramic useful for cooking', 184, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 98
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 99, 'chair', 'A brilliant chair in an stunning blue made of metal useful for writing', 370, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 99
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 100, 'book', 'A amazing book in an gorgeous yellow made of metal useful for writing', 435, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 100
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 101, 'table', 'A brilliant table in an illustrious yellow made of plastic useful for writing', 455, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 101
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 102, 'laptop', 'A wonderful laptop in an magnificent green made of plastic useful for drilling', 193, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 102
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 103, 'table', 'A amazing table in an splendid yellow made of metal useful for cooking', 123, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 103
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 104, 'book', 'A wonderful book in an stunning purple made of plastic useful for painting', 226, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 104
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 105, 'book', 'A brilliant book in an illustrious blue made of glass useful for cutting', 44, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 105
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 106, 'table', 'A spectacular table in an splendid yellow made of glass useful for cooking', 456, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 106
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 107, 'table', 'A spectacular table in an illustrious yellow made of glass useful for cooking', 137, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 107
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 108, 'table', 'A wonderful table in an illustrious red made of wood useful for writing', 488, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 108
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 109, 'book', 'A brilliant book in an stunning blue made of metal useful for painting', 257, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 109
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 110, 'book', 'A spectacular book in an stunning red made of plastic useful for drilling', 165, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 110
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 111, 'hammer', 'A amazing hammer in an splendid green made of ceramic useful for cutting', 278, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 111
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 112, 'book', 'A brilliant book in an stunning purple made of plastic useful for drilling', 141, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 112
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 113, 'hammer', 'A wonderful hammer in an splendid yellow made of metal useful for writing', 227, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 113
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 114, 'hammer', 'A fantastic hammer in an magnificent blue made of wood useful for painting', 78, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 114
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 115, 'chair', 'A spectacular chair in an illustrious blue made of plastic useful for drilling', 293, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 115
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 116, 'chair', 'A amazing chair in an gorgeous red made of ceramic useful for cooking', 370, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 116
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 117, 'chair', 'A amazing chair in an splendid purple made of plastic useful for writing', 108, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 117
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 118, 'book', 'A brilliant book in an illustrious purple made of plastic useful for drilling', 161, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 118
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 119, 'table', 'A wonderful table in an illustrious blue made of wood useful for cutting', 304, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 119
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 120, 'hammer', 'A brilliant hammer in an illustrious green made of ceramic useful for cooking', 407, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 120
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 121, 'hammer', 'A fantastic hammer in an stunning blue made of ceramic useful for writing', 386, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 121
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 122, 'chair', 'A amazing chair in an magnificent red made of glass useful for cooking', 492, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 122
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 123, 'chair', 'A brilliant chair in an illustrious purple made of ceramic useful for drilling', 399, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 123
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 124, 'chair', 'A wonderful chair in an stunning blue made of metal useful for cutting', 217, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 124
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 125, 'hammer', 'A brilliant hammer in an illustrious blue made of plastic useful for drilling', 468, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 125
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 126, 'hammer', 'A fantastic hammer in an splendid red made of wood useful for writing', 212, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 126
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 127, 'laptop', 'A amazing laptop in an gorgeous green made of plastic useful for painting', 126, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 127
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 128, 'hammer', 'A spectacular hammer in an magnificent green made of plastic useful for painting', 471, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 128
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 129, 'chair', 'A spectacular chair in an gorgeous yellow made of plastic useful for cooking', 339, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 129
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 130, 'book', 'A spectacular book in an gorgeous blue made of glass useful for painting', 425, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 130
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 131, 'chair', 'A fantastic chair in an magnificent blue made of ceramic useful for painting', 102, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 131
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 132, 'book', 'A amazing book in an splendid purple made of metal useful for cooking', 355, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 132
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 133, 'book', 'A brilliant book in an magnificent red made of glass useful for cooking', 292, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 133
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 134, 'table', 'A wonderful table in an splendid green made of ceramic useful for writing', 91, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 134
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 135, 'chair', 'A wonderful chair in an stunning purple made of metal useful for writing', 103, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 135
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 136, 'chair', 'A amazing chair in an stunning green made of ceramic useful for cooking', 50, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 136
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 137, 'book', 'A spectacular book in an illustrious purple made of metal useful for painting', 24, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 137
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 138, 'laptop', 'A amazing laptop in an magnificent yellow made of metal useful for drilling', 138, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 138
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 139, 'laptop', 'A brilliant laptop in an magnificent red made of metal useful for writing', 200, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 139
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 140, 'table', 'A fantastic table in an illustrious green made of ceramic useful for drilling', 336, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 140
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 141, 'chair', 'A wonderful chair in an illustrious yellow made of ceramic useful for painting', 84, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 141
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 142, 'book', 'A wonderful book in an illustrious red made of wood useful for writing', 324, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 142
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 143, 'hammer', 'A amazing hammer in an magnificent yellow made of ceramic useful for writing', 143, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 143
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 144, 'table', 'A brilliant table in an illustrious purple made of ceramic useful for writing', 131, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 144
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 145, 'table', 'A spectacular table in an stunning red made of ceramic useful for drilling', 65, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 145
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 146, 'chair', 'A wonderful chair in an gorgeous green made of metal useful for drilling', 356, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 146
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 147, 'laptop', 'A amazing laptop in an stunning red made of plastic useful for painting', 96, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 147
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 148, 'table', 'A spectacular table in an gorgeous purple made of glass useful for cooking', 392, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 148
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 149, 'laptop', 'A fantastic laptop in an gorgeous yellow made of plastic useful for writing', 16, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 149
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 150, 'table', 'A wonderful table in an magnificent red made of glass useful for drilling', 251, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 150
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 151, 'chair', 'A wonderful chair in an illustrious yellow made of metal useful for cooking', 294, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 151
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 152, 'hammer', 'A amazing hammer in an illustrious green made of glass useful for drilling', 378, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 152
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 153, 'laptop', 'A amazing laptop in an stunning red made of ceramic useful for drilling', 300, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 153
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 154, 'hammer', 'A spectacular hammer in an stunning blue made of metal useful for drilling', 23, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 154
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 155, 'hammer', 'A spectacular hammer in an gorgeous yellow made of glass useful for cutting', 273, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 155
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 156, 'hammer', 'A brilliant hammer in an illustrious red made of ceramic useful for cutting', 289, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 156
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 157, 'table', 'A spectacular table in an gorgeous blue made of ceramic useful for painting', 199, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 157
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 158, 'book', 'A brilliant book in an stunning blue made of glass useful for drilling', 208, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 158
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 159, 'laptop', 'A spectacular laptop in an splendid blue made of plastic useful for writing', 449, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 159
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 160, 'table', 'A brilliant table in an magnificent blue made of ceramic useful for writing', 177, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 160
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 161, 'chair', 'A spectacular chair in an stunning blue made of ceramic useful for painting', 409, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 161
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 162, 'chair', 'A amazing chair in an stunning red made of plastic useful for painting', 453, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 162
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 163, 'table', 'A brilliant table in an splendid purple made of glass useful for writing', 351, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 163
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 164, 'chair', 'A amazing chair in an gorgeous green made of plastic useful for cutting', 473, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 164
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 165, 'book', 'A amazing book in an illustrious purple made of plastic useful for writing', 291, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 165
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 166, 'book', 'A wonderful book in an illustrious yellow made of glass useful for cutting', 453, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 166
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 167, 'book', 'A wonderful book in an splendid yellow made of ceramic useful for cooking', 383, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 167
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 168, 'chair', 'A spectacular chair in an gorgeous green made of plastic useful for writing', 421, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 168
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 169, 'laptop', 'A brilliant laptop in an gorgeous yellow made of wood useful for writing', 232, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 169
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 170, 'table', 'A spectacular table in an splendid yellow made of ceramic useful for writing', 296, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 170
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 171, 'book', 'A amazing book in an magnificent purple made of plastic useful for cooking', 473, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 171
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 172, 'laptop', 'A amazing laptop in an gorgeous yellow made of plastic useful for cutting', 389, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 172
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 173, 'book', 'A spectacular book in an splendid yellow made of metal useful for cooking', 430, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 173
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 174, 'table', 'A wonderful table in an stunning red made of wood useful for painting', 61, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 174
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 175, 'book', 'A amazing book in an stunning yellow made of glass useful for writing', 76, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 175
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 176, 'laptop', 'A fantastic laptop in an illustrious green made of metal useful for cutting', 338, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 176
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 177, 'chair', 'A spectacular chair in an gorgeous green made of glass useful for painting', 139, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 177
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 178, 'table', 'A fantastic table in an stunning red made of wood useful for painting', 454, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 178
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 179, 'book', 'A fantastic book in an illustrious purple made of plastic useful for painting', 351, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 179
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 180, 'book', 'A amazing book in an stunning red made of wood useful for painting', 331, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 180
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 181, 'laptop', 'A amazing laptop in an splendid blue made of ceramic useful for painting', 219, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 181
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 182, 'book', 'A fantastic book in an splendid blue made of glass useful for painting', 485, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 182
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 183, 'chair', 'A fantastic chair in an magnificent green made of ceramic useful for drilling', 70, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 183
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 184, 'chair', 'A amazing chair in an gorgeous blue made of metal useful for cooking', 117, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 184
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 185, 'book', 'A brilliant book in an splendid green made of metal useful for painting', 128, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 185
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 186, 'book', 'A fantastic book in an illustrious green made of glass useful for cutting', 406, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 186
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 187, 'book', 'A spectacular book in an stunning yellow made of ceramic useful for writing', 57, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 187
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 188, 'hammer', 'A amazing hammer in an illustrious purple made of metal useful for cooking', 81, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 188
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 189, 'table', 'A brilliant table in an splendid blue made of glass useful for cutting', 35, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 189
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 190, 'hammer', 'A spectacular hammer in an stunning red made of ceramic useful for drilling', 338, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 190
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 191, 'table', 'A brilliant table in an gorgeous yellow made of glass useful for painting', 223, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 191
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 192, 'table', 'A amazing table in an stunning green made of wood useful for cooking', 74, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 192
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 193, 'hammer', 'A brilliant hammer in an magnificent blue made of metal useful for drilling', 284, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 193
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 194, 'chair', 'A fantastic chair in an illustrious green made of glass useful for cooking', 447, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 194
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 195, 'chair', 'A wonderful chair in an illustrious yellow made of wood useful for cooking', 116, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 195
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 196, 'hammer', 'A fantastic hammer in an stunning blue made of glass useful for cutting', 311, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 196
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 197, 'book', 'A fantastic book in an splendid green made of metal useful for painting', 444, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 197
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 198, 'book', 'A fantastic book in an gorgeous yellow made of metal useful for drilling', 332, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 198
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 199, 'laptop', 'A brilliant laptop in an splendid red made of metal useful for cooking', 470, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 199
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 200, 'hammer', 'A amazing hammer in an splendid blue made of glass useful for drilling', 77, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 200
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 201, 'chair', 'A spectacular chair in an magnificent green made of ceramic useful for painting', 135, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 201
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 202, 'chair', 'A spectacular chair in an splendid red made of glass useful for cutting', 149, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 202
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 203, 'laptop', 'A fantastic laptop in an stunning yellow made of metal useful for cutting', 98, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 203
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 204, 'hammer', 'A spectacular hammer in an gorgeous green made of wood useful for cooking', 197, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 204
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 205, 'laptop', 'A spectacular laptop in an stunning red made of metal useful for painting', 490, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 205
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 206, 'laptop', 'A fantastic laptop in an illustrious green made of wood useful for cooking', 66, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 206
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 207, 'laptop', 'A wonderful laptop in an splendid yellow made of wood useful for cutting', 483, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 207
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 208, 'chair', 'A fantastic chair in an gorgeous yellow made of ceramic useful for cutting', 21, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 208
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 209, 'chair', 'A fantastic chair in an illustrious green made of plastic useful for drilling', 77, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 209
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 210, 'chair', 'A wonderful chair in an gorgeous red made of plastic useful for cooking', 468, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 210
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 211, 'laptop', 'A wonderful laptop in an magnificent yellow made of glass useful for drilling', 278, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 211
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 212, 'table', 'A brilliant table in an magnificent purple made of ceramic useful for cooking', 233, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 212
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 213, 'book', 'A amazing book in an splendid green made of wood useful for drilling', 285, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 213
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 214, 'hammer', 'A amazing hammer in an stunning yellow made of wood useful for writing', 121, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 214
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 215, 'table', 'A brilliant table in an stunning yellow made of wood useful for drilling', 385, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 215
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 216, 'chair', 'A spectacular chair in an gorgeous yellow made of ceramic useful for cutting', 283, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 216
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 217, 'table', 'A spectacular table in an magnificent red made of plastic useful for drilling', 147, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 217
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 218, 'table', 'A spectacular table in an magnificent blue made of metal useful for drilling', 117, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 218
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 219, 'chair', 'A spectacular chair in an splendid blue made of plastic useful for drilling', 42, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 219
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 220, 'hammer', 'A spectacular hammer in an stunning blue made of wood useful for writing', 57, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 220
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 221, 'chair', 'A amazing chair in an illustrious red made of metal useful for cooking', 64, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 221
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 222, 'laptop', 'A spectacular laptop in an magnificent purple made of plastic useful for cutting', 18, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 222
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 223, 'hammer', 'A brilliant hammer in an gorgeous purple made of ceramic useful for cooking', 248, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 223
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 224, 'chair', 'A wonderful chair in an magnificent green made of ceramic useful for drilling', 140, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 224
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 225, 'book', 'A wonderful book in an gorgeous yellow made of glass useful for cooking', 194, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 225
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 226, 'laptop', 'A amazing laptop in an stunning red made of glass useful for drilling', 47, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 226
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 227, 'chair', 'A fantastic chair in an stunning yellow made of ceramic useful for painting', 136, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 227
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 228, 'table', 'A spectacular table in an stunning red made of plastic useful for painting', 320, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 228
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 229, 'book', 'A spectacular book in an magnificent red made of glass useful for writing', 404, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 229
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 230, 'table', 'A fantastic table in an splendid red made of plastic useful for painting', 59, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 230
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 231, 'hammer', 'A spectacular hammer in an illustrious yellow made of ceramic useful for writing', 419, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 231
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 232, 'chair', 'A fantastic chair in an splendid purple made of ceramic useful for cutting', 489, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 232
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 233, 'laptop', 'A amazing laptop in an splendid purple made of metal useful for drilling', 34, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 233
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 234, 'laptop', 'A wonderful laptop in an stunning green made of glass useful for drilling', 38, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 234
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 235, 'hammer', 'A spectacular hammer in an magnificent purple made of plastic useful for painting', 288, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 235
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 236, 'book', 'A fantastic book in an stunning blue made of wood useful for cooking', 261, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 236
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 237, 'laptop', 'A spectacular laptop in an illustrious yellow made of metal useful for painting', 286, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 237
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 238, 'book', 'A fantastic book in an splendid purple made of metal useful for painting', 170, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 238
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 239, 'table', 'A amazing table in an splendid purple made of metal useful for cooking', 444, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 239
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 240, 'laptop', 'A fantastic laptop in an splendid blue made of metal useful for writing', 455, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 240
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 241, 'laptop', 'A fantastic laptop in an splendid red made of wood useful for drilling', 137, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 241
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 242, 'chair', 'A brilliant chair in an illustrious purple made of wood useful for cutting', 251, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 242
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 243, 'laptop', 'A fantastic laptop in an stunning purple made of metal useful for cutting', 104, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 243
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 244, 'hammer', 'A wonderful hammer in an magnificent green made of wood useful for painting', 220, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 244
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 245, 'chair', 'A fantastic chair in an illustrious blue made of plastic useful for cutting', 397, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 245
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 246, 'hammer', 'A amazing hammer in an illustrious blue made of wood useful for painting', 207, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 246
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 247, 'table', 'A amazing table in an magnificent red made of metal useful for writing', 194, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 247
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 248, 'laptop', 'A wonderful laptop in an illustrious yellow made of glass useful for cutting', 367, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 248
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 249, 'book', 'A wonderful book in an stunning blue made of glass useful for cooking', 243, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 249
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 250, 'book', 'A spectacular book in an stunning green made of wood useful for writing', 160, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 250
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 251, 'laptop', 'A wonderful laptop in an magnificent purple made of glass useful for cutting', 166, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 251
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 252, 'hammer', 'A amazing hammer in an gorgeous blue made of plastic useful for drilling', 392, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 252
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 253, 'book', 'A spectacular book in an illustrious purple made of ceramic useful for cooking', 24, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 253
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 254, 'chair', 'A wonderful chair in an gorgeous green made of plastic useful for cooking', 152, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 254
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 255, 'hammer', 'A fantastic hammer in an splendid blue made of glass useful for cutting', 473, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 255
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 256, 'chair', 'A amazing chair in an magnificent red made of glass useful for drilling', 36, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 256
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 257, 'chair', 'A fantastic chair in an illustrious purple made of ceramic useful for cutting', 92, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 257
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 258, 'table', 'A wonderful table in an stunning green made of plastic useful for cooking', 164, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 258
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 259, 'chair', 'A fantastic chair in an gorgeous yellow made of ceramic useful for painting', 465, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 259
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 260, 'hammer', 'A wonderful hammer in an magnificent yellow made of wood useful for painting', 373, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 260
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 261, 'laptop', 'A fantastic laptop in an gorgeous red made of ceramic useful for painting', 162, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 261
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 262, 'laptop', 'A spectacular laptop in an magnificent green made of plastic useful for writing', 384, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 262
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 263, 'hammer', 'A fantastic hammer in an stunning red made of wood useful for cutting', 188, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 263
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 264, 'hammer', 'A spectacular hammer in an illustrious yellow made of wood useful for cooking', 282, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 264
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 265, 'book', 'A fantastic book in an splendid green made of metal useful for drilling', 314, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 265
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 266, 'hammer', 'A spectacular hammer in an magnificent red made of glass useful for writing', 190, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 266
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 267, 'laptop', 'A wonderful laptop in an splendid green made of ceramic useful for painting', 248, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 267
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 268, 'book', 'A fantastic book in an gorgeous yellow made of ceramic useful for cooking', 388, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 268
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 269, 'book', 'A spectacular book in an splendid blue made of plastic useful for cooking', 61, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 269
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 270, 'table', 'A spectacular table in an splendid green made of metal useful for writing', 66, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 270
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 271, 'laptop', 'A wonderful laptop in an stunning green made of glass useful for cutting', 136, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 271
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 272, 'chair', 'A amazing chair in an stunning red made of plastic useful for cutting', 161, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 272
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 273, 'chair', 'A fantastic chair in an gorgeous red made of glass useful for writing', 57, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 273
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 274, 'laptop', 'A amazing laptop in an splendid green made of ceramic useful for cooking', 256, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 274
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 275, 'table', 'A fantastic table in an splendid yellow made of plastic useful for writing', 284, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 275
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 276, 'chair', 'A wonderful chair in an magnificent green made of glass useful for cooking', 478, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 276
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 277, 'hammer', 'A fantastic hammer in an gorgeous green made of metal useful for painting', 36, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 277
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 278, 'book', 'A fantastic book in an splendid blue made of ceramic useful for cooking', 299, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 278
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 279, 'hammer', 'A wonderful hammer in an illustrious yellow made of wood useful for cutting', 94, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 279
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 280, 'book', 'A wonderful book in an illustrious red made of ceramic useful for writing', 400, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 280
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 281, 'book', 'A spectacular book in an gorgeous red made of glass useful for cooking', 105, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 281
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 282, 'book', 'A amazing book in an illustrious red made of glass useful for writing', 382, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 282
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 283, 'table', 'A spectacular table in an stunning yellow made of wood useful for cooking', 481, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 283
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 284, 'laptop', 'A wonderful laptop in an gorgeous purple made of metal useful for cutting', 434, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 284
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 285, 'laptop', 'A wonderful laptop in an stunning blue made of wood useful for cooking', 278, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 285
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 286, 'chair', 'A wonderful chair in an stunning purple made of glass useful for cutting', 283, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 286
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 287, 'hammer', 'A brilliant hammer in an splendid purple made of ceramic useful for painting', 79, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 287
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 288, 'table', 'A amazing table in an splendid blue made of metal useful for painting', 283, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 288
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 289, 'chair', 'A wonderful chair in an magnificent blue made of glass useful for painting', 115, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 289
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 290, 'table', 'A brilliant table in an stunning purple made of wood useful for cutting', 89, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 290
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 291, 'laptop', 'A brilliant laptop in an magnificent yellow made of glass useful for cooking', 486, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 291
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 292, 'table', 'A wonderful table in an gorgeous purple made of metal useful for cooking', 284, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 292
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 293, 'table', 'A amazing table in an stunning red made of metal useful for cutting', 13, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 293
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 294, 'hammer', 'A amazing hammer in an gorgeous red made of wood useful for cooking', 105, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 294
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 295, 'hammer', 'A brilliant hammer in an splendid blue made of glass useful for cutting', 255, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 295
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 296, 'chair', 'A wonderful chair in an magnificent purple made of ceramic useful for cutting', 429, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 296
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 297, 'chair', 'A fantastic chair in an magnificent purple made of wood useful for painting', 311, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 297
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 298, 'chair', 'A fantastic chair in an stunning green made of ceramic useful for writing', 265, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 298
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 299, 'book', 'A amazing book in an magnificent red made of glass useful for cutting', 387, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 299
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 300, 'table', 'A wonderful table in an magnificent red made of wood useful for cooking', 209, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 300
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 301, 'laptop', 'A amazing laptop in an splendid yellow made of wood useful for painting', 333, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 301
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 302, 'book', 'A spectacular book in an magnificent yellow made of ceramic useful for cutting', 334, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 302
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 303, 'book', 'A wonderful book in an illustrious blue made of wood useful for cutting', 377, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 303
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 304, 'chair', 'A fantastic chair in an magnificent purple made of ceramic useful for drilling', 436, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 304
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 305, 'laptop', 'A amazing laptop in an stunning purple made of ceramic useful for painting', 316, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 305
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 306, 'laptop', 'A wonderful laptop in an magnificent purple made of plastic useful for writing', 378, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 306
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 307, 'book', 'A fantastic book in an stunning yellow made of glass useful for drilling', 286, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 307
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 308, 'table', 'A fantastic table in an gorgeous red made of wood useful for writing', 372, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 308
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 309, 'laptop', 'A amazing laptop in an stunning purple made of ceramic useful for painting', 94, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 309
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 310, 'laptop', 'A wonderful laptop in an splendid green made of plastic useful for cutting', 229, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 310
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 311, 'hammer', 'A amazing hammer in an splendid blue made of wood useful for drilling', 305, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 311
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 312, 'chair', 'A amazing chair in an splendid blue made of wood useful for cutting', 234, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 312
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 313, 'table', 'A amazing table in an stunning blue made of wood useful for writing', 389, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 313
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 314, 'table', 'A amazing table in an illustrious red made of glass useful for cooking', 34, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 314
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 315, 'laptop', 'A fantastic laptop in an magnificent purple made of metal useful for writing', 422, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 315
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 316, 'table', 'A brilliant table in an magnificent yellow made of ceramic useful for painting', 458, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 316
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 317, 'laptop', 'A spectacular laptop in an stunning blue made of metal useful for painting', 229, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 317
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 318, 'chair', 'A spectacular chair in an magnificent purple made of plastic useful for cooking', 433, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 318
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 319, 'laptop', 'A fantastic laptop in an gorgeous yellow made of glass useful for drilling', 432, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 319
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 320, 'hammer', 'A wonderful hammer in an gorgeous purple made of metal useful for writing', 96, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 320
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 321, 'laptop', 'A fantastic laptop in an stunning purple made of ceramic useful for painting', 156, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 321
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 322, 'book', 'A wonderful book in an illustrious yellow made of wood useful for painting', 464, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 322
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 323, 'book', 'A amazing book in an gorgeous green made of ceramic useful for drilling', 490, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 323
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 324, 'chair', 'A amazing chair in an stunning purple made of ceramic useful for painting', 161, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 324
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 325, 'table', 'A wonderful table in an gorgeous blue made of ceramic useful for drilling', 476, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 325
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 326, 'book', 'A brilliant book in an stunning yellow made of wood useful for cutting', 486, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 326
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 327, 'hammer', 'A brilliant hammer in an illustrious yellow made of ceramic useful for cutting', 310, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 327
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 328, 'laptop', 'A fantastic laptop in an magnificent green made of wood useful for painting', 118, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 328
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 329, 'chair', 'A spectacular chair in an gorgeous yellow made of metal useful for writing', 460, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 329
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 330, 'book', 'A fantastic book in an illustrious green made of wood useful for writing', 333, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 330
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 331, 'book', 'A wonderful book in an stunning blue made of metal useful for cutting', 419, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 331
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 332, 'table', 'A amazing table in an gorgeous purple made of glass useful for cutting', 103, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 332
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 333, 'hammer', 'A spectacular hammer in an splendid purple made of wood useful for painting', 189, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 333
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 334, 'hammer', 'A brilliant hammer in an stunning red made of wood useful for writing', 209, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 334
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 335, 'book', 'A spectacular book in an magnificent yellow made of ceramic useful for painting', 244, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 335
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 336, 'hammer', 'A fantastic hammer in an gorgeous purple made of metal useful for cutting', 62, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 336
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 337, 'chair', 'A wonderful chair in an stunning yellow made of metal useful for drilling', 324, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 337
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 338, 'book', 'A amazing book in an gorgeous green made of ceramic useful for cooking', 431, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 338
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 339, 'table', 'A brilliant table in an stunning yellow made of wood useful for painting', 259, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 339
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 340, 'laptop', 'A brilliant laptop in an stunning blue made of plastic useful for painting', 294, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 340
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 341, 'hammer', 'A spectacular hammer in an gorgeous purple made of glass useful for cutting', 149, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 341
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 342, 'hammer', 'A amazing hammer in an illustrious green made of glass useful for cooking', 65, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 342
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 343, 'table', 'A amazing table in an magnificent blue made of glass useful for cooking', 440, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 343
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 344, 'laptop', 'A amazing laptop in an stunning red made of ceramic useful for writing', 478, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 344
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 345, 'chair', 'A wonderful chair in an stunning green made of metal useful for cooking', 217, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 345
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 346, 'laptop', 'A brilliant laptop in an splendid blue made of metal useful for painting', 452, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 346
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 347, 'table', 'A fantastic table in an magnificent blue made of ceramic useful for drilling', 103, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 347
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 348, 'book', 'A fantastic book in an stunning blue made of metal useful for cooking', 456, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 348
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 349, 'book', 'A wonderful book in an splendid purple made of glass useful for writing', 450, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 349
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 350, 'book', 'A brilliant book in an splendid red made of ceramic useful for drilling', 204, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 350
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 351, 'book', 'A fantastic book in an gorgeous green made of metal useful for drilling', 358, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 351
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 352, 'book', 'A amazing book in an gorgeous purple made of metal useful for painting', 213, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 352
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 353, 'laptop', 'A spectacular laptop in an splendid green made of plastic useful for cutting', 292, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 353
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 354, 'chair', 'A amazing chair in an splendid red made of plastic useful for writing', 345, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 354
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 355, 'chair', 'A brilliant chair in an splendid purple made of wood useful for drilling', 279, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 355
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 356, 'book', 'A amazing book in an illustrious purple made of metal useful for writing', 54, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 356
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 357, 'hammer', 'A fantastic hammer in an stunning purple made of metal useful for cutting', 473, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 357
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 358, 'chair', 'A amazing chair in an illustrious purple made of plastic useful for cooking', 488, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 358
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 359, 'laptop', 'A wonderful laptop in an stunning red made of wood useful for drilling', 296, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 359
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 360, 'table', 'A amazing table in an splendid green made of ceramic useful for cutting', 272, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 360
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 361, 'hammer', 'A brilliant hammer in an stunning blue made of glass useful for drilling', 385, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 361
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 362, 'book', 'A spectacular book in an magnificent green made of glass useful for writing', 368, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 362
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 363, 'laptop', 'A amazing laptop in an stunning purple made of ceramic useful for painting', 355, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 363
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 364, 'table', 'A spectacular table in an stunning blue made of wood useful for writing', 62, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 364
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 365, 'chair', 'A wonderful chair in an magnificent green made of glass useful for painting', 453, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 365
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 366, 'chair', 'A brilliant chair in an magnificent purple made of glass useful for cooking', 78, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 366
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 367, 'laptop', 'A brilliant laptop in an magnificent purple made of ceramic useful for writing', 28, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 367
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 368, 'laptop', 'A brilliant laptop in an splendid blue made of wood useful for cutting', 105, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 368
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 369, 'hammer', 'A spectacular hammer in an gorgeous green made of plastic useful for drilling', 229, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 369
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 370, 'laptop', 'A brilliant laptop in an illustrious yellow made of metal useful for drilling', 473, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 370
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 371, 'hammer', 'A spectacular hammer in an splendid red made of ceramic useful for cooking', 441, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 371
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 372, 'hammer', 'A brilliant hammer in an illustrious blue made of glass useful for painting', 446, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 372
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 373, 'laptop', 'A amazing laptop in an gorgeous green made of ceramic useful for drilling', 160, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 373
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 374, 'book', 'A wonderful book in an gorgeous purple made of metal useful for cutting', 224, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 374
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 375, 'laptop', 'A wonderful laptop in an gorgeous red made of glass useful for drilling', 49, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 375
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 376, 'chair', 'A amazing chair in an magnificent red made of glass useful for cutting', 56, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 376
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 377, 'table', 'A spectacular table in an illustrious green made of metal useful for writing', 422, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 377
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 378, 'laptop', 'A wonderful laptop in an stunning green made of plastic useful for writing', 343, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 378
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 379, 'laptop', 'A wonderful laptop in an illustrious yellow made of wood useful for cooking', 355, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 379
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 380, 'table', 'A amazing table in an magnificent green made of plastic useful for writing', 57, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 380
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 381, 'hammer', 'A spectacular hammer in an splendid purple made of metal useful for painting', 220, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 381
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 382, 'table', 'A brilliant table in an stunning blue made of metal useful for painting', 393, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 382
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 383, 'chair', 'A brilliant chair in an stunning yellow made of wood useful for painting', 410, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 383
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 384, 'table', 'A spectacular table in an magnificent purple made of metal useful for cutting', 299, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 384
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 385, 'table', 'A brilliant table in an stunning red made of metal useful for cutting', 272, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 385
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 386, 'table', 'A brilliant table in an stunning red made of glass useful for writing', 460, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 386
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 387, 'laptop', 'A amazing laptop in an magnificent purple made of wood useful for writing', 14, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 387
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 388, 'hammer', 'A brilliant hammer in an illustrious yellow made of metal useful for drilling', 11, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 388
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 389, 'book', 'A spectacular book in an illustrious red made of ceramic useful for writing', 202, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 389
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 390, 'laptop', 'A amazing laptop in an gorgeous green made of plastic useful for cutting', 275, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 390
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 391, 'hammer', 'A wonderful hammer in an splendid purple made of ceramic useful for painting', 463, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 391
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 392, 'chair', 'A spectacular chair in an magnificent green made of ceramic useful for painting', 326, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 392
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 393, 'book', 'A brilliant book in an stunning blue made of metal useful for writing', 431, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 393
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 394, 'laptop', 'A wonderful laptop in an stunning red made of glass useful for painting', 106, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 394
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 395, 'book', 'A brilliant book in an gorgeous blue made of glass useful for cooking', 273, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 395
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 396, 'table', 'A brilliant table in an magnificent red made of glass useful for drilling', 352, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 396
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 397, 'chair', 'A wonderful chair in an splendid red made of glass useful for painting', 207, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 397
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 398, 'book', 'A spectacular book in an illustrious purple made of plastic useful for cooking', 489, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 398
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 399, 'hammer', 'A amazing hammer in an gorgeous green made of wood useful for cooking', 113, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 399
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 400, 'book', 'A amazing book in an splendid purple made of ceramic useful for cutting', 466, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 400
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 401, 'hammer', 'A amazing hammer in an gorgeous red made of wood useful for painting', 84, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 401
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 402, 'book', 'A wonderful book in an gorgeous blue made of wood useful for cooking', 468, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 402
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 403, 'laptop', 'A spectacular laptop in an illustrious green made of glass useful for writing', 172, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 403
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 404, 'chair', 'A wonderful chair in an illustrious purple made of glass useful for drilling', 141, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 404
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 405, 'laptop', 'A brilliant laptop in an illustrious yellow made of plastic useful for painting', 345, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 405
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 406, 'laptop', 'A wonderful laptop in an illustrious blue made of plastic useful for drilling', 413, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 406
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 407, 'laptop', 'A fantastic laptop in an splendid green made of plastic useful for drilling', 30, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 407
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 408, 'book', 'A fantastic book in an stunning green made of metal useful for cutting', 150, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 408
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 409, 'laptop', 'A brilliant laptop in an gorgeous red made of glass useful for cutting', 113, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 409
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 410, 'chair', 'A brilliant chair in an stunning yellow made of metal useful for painting', 113, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 410
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 411, 'chair', 'A spectacular chair in an magnificent purple made of wood useful for painting', 17, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 411
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 412, 'chair', 'A fantastic chair in an illustrious blue made of wood useful for cutting', 397, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 412
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 413, 'laptop', 'A spectacular laptop in an splendid blue made of glass useful for cooking', 265, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 413
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 414, 'laptop', 'A brilliant laptop in an stunning red made of metal useful for painting', 50, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 414
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 415, 'hammer', 'A amazing hammer in an gorgeous green made of glass useful for drilling', 265, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 415
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 416, 'chair', 'A brilliant chair in an stunning blue made of ceramic useful for writing', 420, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 416
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 417, 'table', 'A spectacular table in an splendid blue made of wood useful for cooking', 448, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 417
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 418, 'laptop', 'A wonderful laptop in an splendid purple made of ceramic useful for cooking', 96, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 418
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 419, 'laptop', 'A spectacular laptop in an stunning blue made of glass useful for writing', 417, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 419
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 420, 'book', 'A spectacular book in an splendid red made of metal useful for cooking', 64, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 420
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 421, 'chair', 'A fantastic chair in an magnificent purple made of wood useful for painting', 169, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 421
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 422, 'table', 'A brilliant table in an stunning yellow made of wood useful for painting', 64, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 422
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 423, 'table', 'A spectacular table in an splendid blue made of glass useful for cutting', 391, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 423
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 424, 'chair', 'A spectacular chair in an illustrious yellow made of plastic useful for drilling', 259, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 424
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 425, 'chair', 'A spectacular chair in an magnificent yellow made of ceramic useful for drilling', 253, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 425
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 426, 'laptop', 'A brilliant laptop in an stunning red made of metal useful for painting', 267, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 426
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 427, 'hammer', 'A spectacular hammer in an magnificent green made of glass useful for writing', 127, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 427
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 428, 'laptop', 'A brilliant laptop in an illustrious purple made of glass useful for drilling', 30, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 428
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 429, 'table', 'A brilliant table in an stunning red made of plastic useful for cooking', 393, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 429
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 430, 'laptop', 'A fantastic laptop in an stunning blue made of glass useful for painting', 65, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 430
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 431, 'chair', 'A brilliant chair in an stunning yellow made of metal useful for cutting', 167, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 431
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 432, 'chair', 'A amazing chair in an stunning blue made of glass useful for drilling', 20, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 432
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 433, 'chair', 'A amazing chair in an magnificent purple made of glass useful for painting', 251, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 433
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 434, 'laptop', 'A spectacular laptop in an splendid red made of glass useful for cutting', 107, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 434
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 435, 'table', 'A fantastic table in an splendid purple made of plastic useful for drilling', 180, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 435
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 436, 'book', 'A amazing book in an gorgeous green made of glass useful for cooking', 307, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 436
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 437, 'hammer', 'A fantastic hammer in an stunning red made of ceramic useful for drilling', 282, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 437
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 438, 'book', 'A fantastic book in an splendid green made of metal useful for writing', 209, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 438
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 439, 'laptop', 'A fantastic laptop in an stunning green made of glass useful for painting', 463, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 439
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 440, 'book', 'A wonderful book in an splendid green made of glass useful for drilling', 255, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 440
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 441, 'laptop', 'A spectacular laptop in an stunning green made of plastic useful for painting', 328, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 441
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 442, 'hammer', 'A wonderful hammer in an gorgeous blue made of glass useful for cooking', 429, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 442
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 443, 'chair', 'A wonderful chair in an illustrious blue made of plastic useful for painting', 298, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 443
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 444, 'hammer', 'A fantastic hammer in an gorgeous purple made of plastic useful for painting', 101, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 444
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 445, 'laptop', 'A brilliant laptop in an magnificent red made of glass useful for cooking', 319, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 445
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 446, 'table', 'A brilliant table in an illustrious green made of glass useful for drilling', 387, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 446
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 447, 'laptop', 'A fantastic laptop in an gorgeous red made of ceramic useful for painting', 198, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 447
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 448, 'hammer', 'A fantastic hammer in an splendid blue made of metal useful for painting', 459, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 448
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 449, 'chair', 'A brilliant chair in an gorgeous blue made of glass useful for painting', 483, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 449
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 450, 'laptop', 'A spectacular laptop in an splendid blue made of wood useful for cutting', 446, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 450
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 451, 'laptop', 'A spectacular laptop in an stunning blue made of ceramic useful for cooking', 459, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 451
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 452, 'table', 'A fantastic table in an magnificent green made of metal useful for writing', 245, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 452
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 453, 'chair', 'A wonderful chair in an stunning red made of plastic useful for cutting', 78, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 453
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 454, 'laptop', 'A spectacular laptop in an illustrious yellow made of ceramic useful for cooking', 385, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 454
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 455, 'hammer', 'A amazing hammer in an illustrious red made of ceramic useful for drilling', 494, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 455
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 456, 'laptop', 'A fantastic laptop in an magnificent green made of plastic useful for writing', 406, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 456
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 457, 'book', 'A wonderful book in an magnificent red made of wood useful for painting', 177, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 457
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 458, 'table', 'A wonderful table in an stunning red made of plastic useful for painting', 383, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 458
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 459, 'hammer', 'A wonderful hammer in an gorgeous blue made of ceramic useful for cooking', 84, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 459
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 460, 'hammer', 'A wonderful hammer in an gorgeous purple made of ceramic useful for cooking', 261, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 460
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 461, 'laptop', 'A fantastic laptop in an gorgeous red made of ceramic useful for cutting', 461, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 461
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 462, 'book', 'A amazing book in an stunning green made of wood useful for writing', 361, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 462
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 463, 'table', 'A brilliant table in an gorgeous purple made of ceramic useful for drilling', 303, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 463
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 464, 'laptop', 'A amazing laptop in an splendid green made of ceramic useful for cutting', 357, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 464
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 465, 'table', 'A wonderful table in an magnificent blue made of ceramic useful for cooking', 496, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 465
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 466, 'chair', 'A brilliant chair in an splendid purple made of ceramic useful for writing', 80, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 466
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 467, 'hammer', 'A amazing hammer in an splendid yellow made of glass useful for writing', 445, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 467
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 468, 'hammer', 'A amazing hammer in an magnificent purple made of ceramic useful for painting', 156, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 468
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 469, 'table', 'A fantastic table in an splendid green made of metal useful for cooking', 230, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 469
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 470, 'book', 'A fantastic book in an stunning green made of metal useful for cutting', 86, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 470
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 471, 'chair', 'A wonderful chair in an illustrious green made of metal useful for painting', 422, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 471
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 472, 'table', 'A fantastic table in an stunning purple made of wood useful for cutting', 282, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 472
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 473, 'book', 'A spectacular book in an splendid purple made of metal useful for painting', 73, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 473
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 474, 'chair', 'A brilliant chair in an splendid blue made of metal useful for cooking', 385, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 474
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 475, 'book', 'A amazing book in an magnificent green made of metal useful for cooking', 478, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 475
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 476, 'chair', 'A wonderful chair in an illustrious yellow made of ceramic useful for cooking', 179, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 476
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 477, 'book', 'A spectacular book in an illustrious blue made of metal useful for cooking', 98, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 477
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 478, 'chair', 'A fantastic chair in an illustrious red made of ceramic useful for writing', 404, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 478
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 479, 'hammer', 'A amazing hammer in an splendid purple made of wood useful for painting', 371, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 479
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 480, 'book', 'A amazing book in an splendid green made of metal useful for drilling', 297, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 480
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 481, 'chair', 'A spectacular chair in an illustrious green made of plastic useful for writing', 482, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 481
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 482, 'table', 'A fantastic table in an gorgeous blue made of plastic useful for cooking', 219, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 482
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 483, 'chair', 'A wonderful chair in an gorgeous blue made of metal useful for drilling', 424, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 483
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 484, 'chair', 'A wonderful chair in an stunning red made of ceramic useful for drilling', 393, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 484
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 485, 'laptop', 'A fantastic laptop in an illustrious purple made of plastic useful for cooking', 61, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 485
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 486, 'hammer', 'A brilliant hammer in an gorgeous yellow made of metal useful for drilling', 240, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 486
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 487, 'book', 'A amazing book in an magnificent blue made of wood useful for drilling', 356, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 487
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 488, 'book', 'A spectacular book in an stunning purple made of wood useful for drilling', 57, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 488
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 489, 'table', 'A brilliant table in an splendid purple made of wood useful for writing', 232, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 489
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 490, 'table', 'A brilliant table in an illustrious green made of plastic useful for cutting', 247, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 490
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 491, 'book', 'A fantastic book in an splendid yellow made of plastic useful for drilling', 354, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 491
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 492, 'chair', 'A wonderful chair in an magnificent red made of ceramic useful for cutting', 166, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 492
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 493, 'book', 'A wonderful book in an splendid purple made of ceramic useful for cutting', 42, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 493
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 494, 'table', 'A brilliant table in an illustrious red made of metal useful for cooking', 276, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 494
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 495, 'hammer', 'A amazing hammer in an stunning purple made of wood useful for cutting', 187, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 495
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 496, 'chair', 'A brilliant chair in an stunning blue made of wood useful for writing', 480, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 496
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 497, 'hammer', 'A spectacular hammer in an gorgeous blue made of glass useful for cutting', 216, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 497
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 498, 'hammer', 'A amazing hammer in an splendid green made of plastic useful for writing', 465, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 498
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 499, 'laptop', 'A wonderful laptop in an illustrious green made of metal useful for painting', 362, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 499
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 500, 'hammer', 'A amazing hammer in an stunning blue made of wood useful for drilling', 70, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 500
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 501, 'hammer', 'A wonderful hammer in an magnificent blue made of metal useful for painting', 439, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 501
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 502, 'laptop', 'A brilliant laptop in an illustrious blue made of ceramic useful for writing', 219, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 502
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 503, 'table', 'A brilliant table in an illustrious red made of glass useful for writing', 19, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 503
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 504, 'table', 'A fantastic table in an splendid purple made of plastic useful for drilling', 32, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 504
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 505, 'table', 'A fantastic table in an illustrious green made of ceramic useful for cutting', 101, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 505
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 506, 'table', 'A wonderful table in an splendid green made of ceramic useful for cooking', 310, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 506
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 507, 'book', 'A wonderful book in an magnificent blue made of wood useful for cooking', 118, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 507
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 508, 'table', 'A spectacular table in an splendid green made of ceramic useful for cutting', 61, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 508
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 509, 'laptop', 'A spectacular laptop in an splendid blue made of ceramic useful for cutting', 376, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 509
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 510, 'chair', 'A spectacular chair in an illustrious blue made of wood useful for painting', 246, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 510
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 511, 'laptop', 'A fantastic laptop in an illustrious red made of ceramic useful for painting', 173, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 511
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 512, 'book', 'A fantastic book in an splendid red made of plastic useful for drilling', 399, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 512
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 513, 'hammer', 'A amazing hammer in an splendid blue made of wood useful for drilling', 371, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 513
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 514, 'hammer', 'A brilliant hammer in an magnificent blue made of ceramic useful for drilling', 149, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 514
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 515, 'chair', 'A fantastic chair in an magnificent green made of ceramic useful for writing', 277, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 515
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 516, 'laptop', 'A amazing laptop in an magnificent red made of ceramic useful for drilling', 356, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 516
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 517, 'book', 'A fantastic book in an magnificent red made of ceramic useful for drilling', 440, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 517
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 518, 'chair', 'A fantastic chair in an splendid yellow made of ceramic useful for writing', 424, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 518
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 519, 'chair', 'A brilliant chair in an splendid red made of plastic useful for cooking', 136, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 519
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 520, 'laptop', 'A amazing laptop in an illustrious purple made of glass useful for painting', 329, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 520
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 521, 'chair', 'A amazing chair in an stunning purple made of metal useful for painting', 33, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 521
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 522, 'hammer', 'A brilliant hammer in an splendid red made of metal useful for cooking', 156, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 522
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 523, 'laptop', 'A fantastic laptop in an stunning blue made of glass useful for cutting', 154, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 523
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 524, 'hammer', 'A brilliant hammer in an splendid red made of metal useful for painting', 13, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 524
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 525, 'chair', 'A brilliant chair in an illustrious purple made of wood useful for painting', 69, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 525
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 526, 'table', 'A spectacular table in an splendid red made of plastic useful for painting', 468, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 526
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 527, 'book', 'A wonderful book in an stunning blue made of plastic useful for painting', 259, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 527
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 528, 'book', 'A fantastic book in an illustrious purple made of glass useful for drilling', 330, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 528
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 529, 'table', 'A brilliant table in an magnificent yellow made of plastic useful for cutting', 441, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 529
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 530, 'laptop', 'A amazing laptop in an illustrious green made of glass useful for writing', 381, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 530
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 531, 'laptop', 'A brilliant laptop in an stunning green made of plastic useful for cutting', 47, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 531
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 532, 'book', 'A wonderful book in an illustrious blue made of glass useful for cutting', 49, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 532
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 533, 'chair', 'A spectacular chair in an stunning blue made of wood useful for cooking', 303, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 533
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 534, 'chair', 'A amazing chair in an splendid blue made of glass useful for drilling', 412, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 534
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 535, 'table', 'A brilliant table in an gorgeous red made of wood useful for drilling', 383, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 535
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 536, 'chair', 'A fantastic chair in an splendid blue made of wood useful for writing', 210, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 536
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 537, 'hammer', 'A brilliant hammer in an magnificent yellow made of plastic useful for cooking', 89, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 537
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 538, 'hammer', 'A wonderful hammer in an stunning blue made of wood useful for cooking', 489, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 538
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 539, 'book', 'A spectacular book in an gorgeous red made of wood useful for drilling', 255, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 539
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 540, 'book', 'A fantastic book in an stunning red made of metal useful for cooking', 216, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 540
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 541, 'chair', 'A brilliant chair in an stunning yellow made of metal useful for cutting', 498, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 541
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 542, 'table', 'A spectacular table in an stunning blue made of ceramic useful for writing', 240, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 542
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 543, 'chair', 'A fantastic chair in an magnificent green made of glass useful for painting', 332, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 543
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 544, 'laptop', 'A fantastic laptop in an splendid green made of wood useful for cutting', 235, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 544
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 545, 'chair', 'A amazing chair in an splendid yellow made of metal useful for writing', 291, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 545
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 546, 'chair', 'A spectacular chair in an illustrious purple made of glass useful for cooking', 451, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 546
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 547, 'book', 'A fantastic book in an gorgeous blue made of ceramic useful for painting', 480, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 547
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 548, 'hammer', 'A brilliant hammer in an stunning red made of wood useful for cutting', 130, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 548
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 549, 'chair', 'A spectacular chair in an illustrious green made of glass useful for cutting', 164, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 549
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 550, 'table', 'A fantastic table in an illustrious green made of ceramic useful for cutting', 469, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 550
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 551, 'table', 'A amazing table in an magnificent red made of glass useful for writing', 389, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 551
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 552, 'laptop', 'A fantastic laptop in an gorgeous purple made of wood useful for cutting', 308, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 552
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 553, 'laptop', 'A fantastic laptop in an splendid red made of glass useful for cooking', 60, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 553
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 554, 'table', 'A wonderful table in an gorgeous yellow made of metal useful for writing', 100, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 554
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 555, 'laptop', 'A brilliant laptop in an stunning blue made of metal useful for cutting', 165, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 555
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 556, 'laptop', 'A wonderful laptop in an magnificent purple made of glass useful for drilling', 116, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 556
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 557, 'laptop', 'A brilliant laptop in an illustrious purple made of plastic useful for drilling', 252, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 557
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 558, 'table', 'A fantastic table in an illustrious green made of wood useful for cooking', 464, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 558
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 559, 'table', 'A brilliant table in an magnificent green made of metal useful for drilling', 149, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 559
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 560, 'chair', 'A brilliant chair in an magnificent red made of metal useful for writing', 475, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 560
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 561, 'chair', 'A brilliant chair in an splendid green made of glass useful for cooking', 485, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 561
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 562, 'chair', 'A fantastic chair in an magnificent green made of metal useful for cutting', 275, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 562
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 563, 'chair', 'A amazing chair in an stunning purple made of wood useful for writing', 302, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 563
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 564, 'book', 'A brilliant book in an gorgeous yellow made of wood useful for painting', 87, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 564
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 565, 'book', 'A amazing book in an stunning blue made of glass useful for cooking', 363, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 565
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 566, 'table', 'A amazing table in an illustrious yellow made of wood useful for writing', 499, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 566
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 567, 'book', 'A wonderful book in an magnificent purple made of ceramic useful for writing', 324, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 567
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 568, 'book', 'A wonderful book in an gorgeous green made of wood useful for drilling', 255, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 568
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 569, 'hammer', 'A amazing hammer in an illustrious red made of metal useful for writing', 407, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 569
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 570, 'chair', 'A spectacular chair in an splendid green made of ceramic useful for painting', 18, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 570
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 571, 'chair', 'A spectacular chair in an magnificent blue made of plastic useful for cooking', 458, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 571
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 572, 'table', 'A fantastic table in an magnificent green made of metal useful for cutting', 138, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 572
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 573, 'table', 'A brilliant table in an stunning yellow made of wood useful for writing', 472, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 573
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 574, 'book', 'A spectacular book in an magnificent green made of ceramic useful for cooking', 237, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 574
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 575, 'chair', 'A brilliant chair in an magnificent yellow made of plastic useful for cooking', 46, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 575
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 576, 'book', 'A spectacular book in an splendid green made of glass useful for cutting', 338, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 576
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 577, 'hammer', 'A amazing hammer in an magnificent blue made of plastic useful for cutting', 449, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 577
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 578, 'table', 'A wonderful table in an stunning red made of ceramic useful for cooking', 95, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 578
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 579, 'table', 'A wonderful table in an illustrious blue made of glass useful for drilling', 166, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 579
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 580, 'laptop', 'A wonderful laptop in an splendid yellow made of plastic useful for writing', 312, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 580
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 581, 'chair', 'A amazing chair in an gorgeous blue made of ceramic useful for writing', 435, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 581
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 582, 'book', 'A brilliant book in an stunning green made of ceramic useful for drilling', 124, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 582
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 583, 'book', 'A spectacular book in an gorgeous red made of metal useful for cooking', 189, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 583
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 584, 'chair', 'A fantastic chair in an gorgeous yellow made of metal useful for writing', 364, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 584
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 585, 'chair', 'A spectacular chair in an gorgeous yellow made of plastic useful for painting', 431, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 585
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 586, 'table', 'A spectacular table in an gorgeous green made of ceramic useful for painting', 403, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 586
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 587, 'chair', 'A fantastic chair in an gorgeous purple made of plastic useful for cutting', 376, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 587
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 588, 'book', 'A amazing book in an stunning purple made of plastic useful for drilling', 295, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 588
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 589, 'chair', 'A amazing chair in an stunning purple made of glass useful for drilling', 21, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 589
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 590, 'book', 'A fantastic book in an stunning green made of wood useful for drilling', 222, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 590
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 591, 'table', 'A spectacular table in an gorgeous red made of glass useful for writing', 181, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 591
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 592, 'book', 'A fantastic book in an stunning yellow made of wood useful for cutting', 124, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 592
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 593, 'book', 'A fantastic book in an gorgeous green made of metal useful for cutting', 386, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 593
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 594, 'hammer', 'A wonderful hammer in an stunning yellow made of wood useful for cooking', 408, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 594
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 595, 'laptop', 'A amazing laptop in an splendid purple made of ceramic useful for cutting', 419, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 595
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 596, 'book', 'A wonderful book in an splendid green made of glass useful for painting', 183, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 596
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 597, 'book', 'A wonderful book in an illustrious red made of plastic useful for painting', 334, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 597
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 598, 'chair', 'A spectacular chair in an magnificent purple made of metal useful for cooking', 137, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 598
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 599, 'chair', 'A amazing chair in an illustrious yellow made of metal useful for cooking', 147, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 599
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 600, 'hammer', 'A amazing hammer in an illustrious yellow made of metal useful for drilling', 133, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 600
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 601, 'hammer', 'A fantastic hammer in an illustrious blue made of ceramic useful for cutting', 445, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 601
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 602, 'chair', 'A fantastic chair in an magnificent yellow made of metal useful for cutting', 153, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 602
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 603, 'table', 'A spectacular table in an stunning blue made of plastic useful for drilling', 131, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 603
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 604, 'book', 'A amazing book in an gorgeous red made of plastic useful for cooking', 496, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 604
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 605, 'chair', 'A brilliant chair in an gorgeous purple made of metal useful for drilling', 483, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 605
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 606, 'chair', 'A spectacular chair in an illustrious blue made of plastic useful for cutting', 228, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 606
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 607, 'hammer', 'A brilliant hammer in an magnificent green made of glass useful for cutting', 112, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 607
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 608, 'laptop', 'A wonderful laptop in an splendid purple made of plastic useful for drilling', 221, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 608
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 609, 'table', 'A amazing table in an magnificent blue made of plastic useful for cooking', 318, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 609
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 610, 'book', 'A wonderful book in an illustrious blue made of wood useful for cooking', 164, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 610
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 611, 'laptop', 'A amazing laptop in an stunning yellow made of ceramic useful for cutting', 97, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 611
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 612, 'table', 'A wonderful table in an illustrious yellow made of ceramic useful for cooking', 90, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 612
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 613, 'laptop', 'A wonderful laptop in an stunning red made of wood useful for cooking', 122, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 613
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 614, 'book', 'A amazing book in an splendid yellow made of wood useful for writing', 468, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 614
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 615, 'table', 'A fantastic table in an magnificent yellow made of plastic useful for cooking', 467, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 615
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 616, 'chair', 'A fantastic chair in an splendid yellow made of wood useful for cooking', 56, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 616
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 617, 'laptop', 'A fantastic laptop in an magnificent red made of wood useful for cutting', 134, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 617
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 618, 'book', 'A fantastic book in an illustrious green made of wood useful for cooking', 151, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 618
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 619, 'table', 'A spectacular table in an gorgeous purple made of wood useful for painting', 242, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 619
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 620, 'book', 'A amazing book in an stunning yellow made of wood useful for painting', 287, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 620
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 621, 'chair', 'A brilliant chair in an splendid red made of wood useful for cooking', 320, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 621
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 622, 'laptop', 'A brilliant laptop in an stunning green made of plastic useful for drilling', 258, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 622
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 623, 'book', 'A fantastic book in an splendid purple made of wood useful for cutting', 94, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 623
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 624, 'hammer', 'A fantastic hammer in an gorgeous yellow made of wood useful for cooking', 233, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 624
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 625, 'hammer', 'A brilliant hammer in an stunning purple made of ceramic useful for cutting', 11, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 625
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 626, 'chair', 'A brilliant chair in an stunning red made of ceramic useful for cutting', 139, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 626
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 627, 'laptop', 'A brilliant laptop in an magnificent yellow made of metal useful for writing', 15, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 627
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 628, 'chair', 'A amazing chair in an stunning purple made of plastic useful for drilling', 220, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 628
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 629, 'table', 'A amazing table in an illustrious yellow made of wood useful for painting', 268, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 629
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 630, 'laptop', 'A spectacular laptop in an stunning purple made of glass useful for writing', 240, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 630
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 631, 'hammer', 'A wonderful hammer in an stunning purple made of plastic useful for writing', 198, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 631
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 632, 'table', 'A amazing table in an illustrious blue made of ceramic useful for cooking', 79, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 632
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 633, 'hammer', 'A wonderful hammer in an splendid yellow made of plastic useful for drilling', 378, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 633
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 634, 'chair', 'A wonderful chair in an stunning blue made of wood useful for painting', 372, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 634
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 635, 'chair', 'A wonderful chair in an stunning purple made of wood useful for drilling', 258, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 635
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 636, 'laptop', 'A fantastic laptop in an splendid red made of wood useful for drilling', 89, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 636
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 637, 'laptop', 'A amazing laptop in an gorgeous red made of plastic useful for cutting', 485, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 637
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 638, 'book', 'A fantastic book in an illustrious purple made of glass useful for cooking', 82, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 638
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 639, 'chair', 'A fantastic chair in an stunning red made of plastic useful for drilling', 295, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 639
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 640, 'table', 'A spectacular table in an splendid blue made of plastic useful for cutting', 281, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 640
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 641, 'laptop', 'A spectacular laptop in an illustrious red made of ceramic useful for painting', 123, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 641
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 642, 'book', 'A fantastic book in an magnificent red made of plastic useful for drilling', 246, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 642
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 643, 'book', 'A brilliant book in an magnificent green made of metal useful for cooking', 433, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 643
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 644, 'table', 'A amazing table in an magnificent yellow made of glass useful for drilling', 349, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 644
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 645, 'book', 'A fantastic book in an magnificent yellow made of ceramic useful for drilling', 367, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 645
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 646, 'chair', 'A spectacular chair in an magnificent purple made of ceramic useful for cooking', 132, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 646
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 647, 'chair', 'A amazing chair in an illustrious red made of plastic useful for writing', 380, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 647
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 648, 'book', 'A amazing book in an splendid purple made of plastic useful for drilling', 199, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 648
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 649, 'book', 'A brilliant book in an splendid yellow made of metal useful for cooking', 34, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 649
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 650, 'table', 'A spectacular table in an magnificent purple made of ceramic useful for writing', 283, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 650
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 651, 'book', 'A wonderful book in an stunning blue made of metal useful for drilling', 441, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 651
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 652, 'book', 'A amazing book in an splendid purple made of glass useful for drilling', 124, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 652
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 653, 'book', 'A amazing book in an stunning green made of metal useful for cutting', 113, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 653
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 654, 'hammer', 'A wonderful hammer in an splendid yellow made of wood useful for drilling', 263, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 654
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 655, 'book', 'A wonderful book in an splendid green made of plastic useful for drilling', 316, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 655
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 656, 'chair', 'A fantastic chair in an splendid purple made of ceramic useful for writing', 488, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 656
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 657, 'table', 'A spectacular table in an splendid purple made of glass useful for writing', 250, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 657
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 658, 'laptop', 'A fantastic laptop in an magnificent red made of glass useful for cooking', 401, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 658
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 659, 'book', 'A brilliant book in an gorgeous blue made of plastic useful for painting', 191, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 659
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 660, 'chair', 'A spectacular chair in an gorgeous purple made of glass useful for painting', 321, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 660
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 661, 'laptop', 'A spectacular laptop in an stunning blue made of glass useful for writing', 106, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 661
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 662, 'laptop', 'A brilliant laptop in an stunning yellow made of metal useful for cooking', 376, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 662
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 663, 'table', 'A spectacular table in an illustrious yellow made of plastic useful for cutting', 213, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 663
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 664, 'chair', 'A wonderful chair in an gorgeous purple made of wood useful for cooking', 95, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 664
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 665, 'table', 'A spectacular table in an illustrious green made of glass useful for writing', 63, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 665
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 666, 'laptop', 'A fantastic laptop in an illustrious green made of metal useful for cooking', 204, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 666
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 667, 'table', 'A wonderful table in an illustrious green made of ceramic useful for painting', 398, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 667
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 668, 'chair', 'A fantastic chair in an splendid blue made of glass useful for cutting', 142, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 668
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 669, 'table', 'A amazing table in an illustrious red made of ceramic useful for writing', 336, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 669
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 670, 'laptop', 'A fantastic laptop in an splendid blue made of wood useful for painting', 100, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 670
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 671, 'table', 'A brilliant table in an splendid red made of metal useful for cooking', 230, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 671
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 672, 'book', 'A wonderful book in an magnificent red made of metal useful for painting', 83, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 672
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 673, 'laptop', 'A amazing laptop in an splendid purple made of plastic useful for cutting', 430, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 673
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 674, 'book', 'A amazing book in an illustrious red made of ceramic useful for painting', 193, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 674
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 675, 'table', 'A amazing table in an illustrious green made of ceramic useful for cooking', 336, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 675
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 676, 'table', 'A amazing table in an stunning yellow made of glass useful for painting', 177, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 676
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 677, 'hammer', 'A wonderful hammer in an splendid green made of plastic useful for cooking', 299, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 677
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 678, 'book', 'A wonderful book in an magnificent yellow made of wood useful for writing', 334, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 678
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 679, 'table', 'A fantastic table in an illustrious purple made of glass useful for painting', 485, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 679
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 680, 'table', 'A fantastic table in an splendid yellow made of metal useful for writing', 384, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 680
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 681, 'laptop', 'A spectacular laptop in an gorgeous red made of metal useful for cutting', 481, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 681
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 682, 'hammer', 'A fantastic hammer in an gorgeous green made of metal useful for cooking', 191, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 682
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 683, 'book', 'A wonderful book in an magnificent purple made of plastic useful for drilling', 226, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 683
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 684, 'laptop', 'A amazing laptop in an stunning purple made of plastic useful for cooking', 346, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 684
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 685, 'hammer', 'A wonderful hammer in an magnificent purple made of wood useful for cooking', 358, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 685
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 686, 'laptop', 'A amazing laptop in an stunning red made of metal useful for drilling', 40, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 686
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 687, 'table', 'A fantastic table in an magnificent yellow made of ceramic useful for writing', 87, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 687
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 688, 'book', 'A brilliant book in an gorgeous yellow made of plastic useful for painting', 111, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 688
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 689, 'laptop', 'A spectacular laptop in an illustrious green made of ceramic useful for writing', 477, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 689
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 690, 'laptop', 'A amazing laptop in an illustrious yellow made of plastic useful for painting', 430, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 690
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 691, 'book', 'A spectacular book in an gorgeous green made of glass useful for painting', 246, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 691
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 692, 'table', 'A brilliant table in an magnificent green made of ceramic useful for drilling', 317, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 692
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 693, 'hammer', 'A brilliant hammer in an gorgeous green made of plastic useful for cooking', 210, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 693
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 694, 'chair', 'A brilliant chair in an gorgeous yellow made of metal useful for cooking', 405, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 694
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 695, 'table', 'A fantastic table in an stunning purple made of plastic useful for writing', 383, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 695
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 696, 'laptop', 'A spectacular laptop in an splendid yellow made of ceramic useful for cooking', 372, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 696
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 697, 'hammer', 'A fantastic hammer in an illustrious green made of ceramic useful for cooking', 50, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 697
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 698, 'laptop', 'A wonderful laptop in an gorgeous green made of ceramic useful for cooking', 416, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 698
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 699, 'chair', 'A spectacular chair in an gorgeous purple made of plastic useful for writing', 258, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 699
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 700, 'hammer', 'A spectacular hammer in an magnificent red made of plastic useful for drilling', 190, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 700
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 701, 'hammer', 'A spectacular hammer in an stunning blue made of ceramic useful for painting', 289, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 701
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 702, 'hammer', 'A fantastic hammer in an stunning green made of glass useful for drilling', 269, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 702
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 703, 'table', 'A fantastic table in an illustrious blue made of wood useful for painting', 342, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 703
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 704, 'table', 'A spectacular table in an stunning yellow made of glass useful for writing', 13, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 704
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 705, 'book', 'A wonderful book in an illustrious blue made of glass useful for painting', 128, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 705
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 706, 'table', 'A wonderful table in an gorgeous blue made of wood useful for cutting', 200, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 706
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 707, 'table', 'A fantastic table in an magnificent red made of ceramic useful for cutting', 265, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 707
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 708, 'chair', 'A wonderful chair in an gorgeous blue made of ceramic useful for drilling', 57, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 708
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 709, 'hammer', 'A brilliant hammer in an gorgeous blue made of wood useful for writing', 350, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 709
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 710, 'hammer', 'A spectacular hammer in an gorgeous green made of ceramic useful for writing', 188, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 710
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 711, 'hammer', 'A wonderful hammer in an splendid red made of ceramic useful for drilling', 109, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 711
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 712, 'hammer', 'A amazing hammer in an gorgeous purple made of glass useful for writing', 260, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 712
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 713, 'book', 'A wonderful book in an magnificent yellow made of glass useful for drilling', 344, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 713
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 714, 'laptop', 'A fantastic laptop in an gorgeous blue made of metal useful for writing', 309, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 714
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 715, 'hammer', 'A brilliant hammer in an magnificent blue made of glass useful for drilling', 247, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 715
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 716, 'table', 'A fantastic table in an gorgeous red made of glass useful for cooking', 440, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 716
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 717, 'laptop', 'A amazing laptop in an gorgeous yellow made of glass useful for painting', 290, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 717
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 718, 'table', 'A amazing table in an stunning blue made of metal useful for drilling', 201, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 718
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 719, 'laptop', 'A amazing laptop in an gorgeous purple made of ceramic useful for cooking', 471, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 719
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 720, 'chair', 'A fantastic chair in an magnificent red made of ceramic useful for drilling', 323, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 720
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 721, 'laptop', 'A amazing laptop in an stunning green made of ceramic useful for writing', 460, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 721
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 722, 'book', 'A brilliant book in an gorgeous red made of ceramic useful for writing', 228, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 722
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 723, 'book', 'A amazing book in an illustrious purple made of wood useful for cooking', 347, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 723
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 724, 'book', 'A brilliant book in an stunning red made of ceramic useful for drilling', 286, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 724
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 725, 'hammer', 'A amazing hammer in an magnificent blue made of plastic useful for cooking', 380, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 725
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 726, 'book', 'A brilliant book in an stunning yellow made of ceramic useful for writing', 133, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 726
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 727, 'book', 'A wonderful book in an splendid red made of plastic useful for drilling', 68, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 727
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 728, 'hammer', 'A fantastic hammer in an splendid yellow made of metal useful for cooking', 62, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 728
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 729, 'chair', 'A brilliant chair in an splendid green made of wood useful for cooking', 287, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 729
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 730, 'hammer', 'A amazing hammer in an splendid green made of metal useful for painting', 296, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 730
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 731, 'table', 'A spectacular table in an splendid red made of wood useful for drilling', 240, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 731
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 732, 'chair', 'A brilliant chair in an gorgeous red made of plastic useful for cutting', 410, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 732
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 733, 'hammer', 'A fantastic hammer in an splendid yellow made of glass useful for drilling', 20, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 733
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 734, 'hammer', 'A fantastic hammer in an magnificent red made of metal useful for writing', 161, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 734
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 735, 'table', 'A wonderful table in an splendid blue made of plastic useful for cutting', 312, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 735
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 736, 'laptop', 'A wonderful laptop in an magnificent green made of metal useful for painting', 170, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 736
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 737, 'table', 'A amazing table in an splendid green made of glass useful for cutting', 487, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 737
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 738, 'chair', 'A spectacular chair in an illustrious green made of metal useful for painting', 150, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 738
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 739, 'table', 'A amazing table in an gorgeous purple made of ceramic useful for cutting', 174, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'table'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 739
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 740, 'chair', 'A brilliant chair in an stunning green made of metal useful for cooking', 370, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 740
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 741, 'laptop', 'A spectacular laptop in an stunning green made of ceramic useful for writing', 486, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 741
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 742, 'chair', 'A spectacular chair in an stunning yellow made of glass useful for writing', 56, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'chair'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 742
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 743, 'hammer', 'A brilliant hammer in an illustrious red made of wood useful for painting', 213, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 743
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 744, 'book', 'A spectacular book in an stunning blue made of metal useful for cutting', 14, 2
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 744
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 745, 'book', 'A brilliant book in an illustrious blue made of plastic useful for painting', 397, 1
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 745
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 746, 'laptop', 'A wonderful laptop in an splendid yellow made of glass useful for drilling', 182, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 746
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 747, 'laptop', 'A amazing laptop in an splendid green made of plastic useful for drilling', 490, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 747
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 748, 'hammer', 'A brilliant hammer in an illustrious blue made of ceramic useful for painting', 243, 4
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'hammer'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 748
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 749, 'book', 'A wonderful book in an gorgeous red made of plastic useful for drilling', 312, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'book'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 749
             );
INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT 750, 'laptop', 'A brilliant laptop in an splendid red made of metal useful for drilling', 498, 3
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = 'laptop'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = 750
             );
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('456', 'Gamma Warehouse', '9402');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('331', 'Alpha Warehouse', '8025');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('639', 'Epsilon Warehouse', '9036');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('987', 'Beta Warehouse', '9636');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('785', 'Gamma Warehouse', '7024');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('722', 'Gamma Warehouse', '6948');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('344', 'Alpha Warehouse', '5300');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('143', 'Delta Warehouse', '4423');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('776', 'Delta Warehouse', '5355');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('481', 'Beta Warehouse', '7773');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('494', 'Delta Warehouse', '4276');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('922', 'Beta Warehouse', '9302');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('537', 'Epsilon Warehouse', '3014');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('715', 'Delta Warehouse', '7675');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('692', 'Alpha Warehouse', '4407');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('765', 'Epsilon Warehouse', '6739');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('578', 'Beta Warehouse', '8968');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('219', 'Epsilon Warehouse', '6691');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('850', 'Delta Warehouse', '9831');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('442', 'Delta Warehouse', '1616');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('382', 'Alpha Warehouse', '4066');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('135', 'Epsilon Warehouse', '7922');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('652', 'Gamma Warehouse', '6821');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('728', 'Delta Warehouse', '2332');
INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('654', 'Beta Warehouse', '8537');
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (167, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 48);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (85, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 152);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (188, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 237);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (63, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 368);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (227, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 205);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (303, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 311);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (140, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 165);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (202, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 111);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (89, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 418);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (253, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 172);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (291, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 169);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (253, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 352);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (89, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 218);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (204, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 219);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (85, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 55);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (68, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 454);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (182, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 303);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (114, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 450);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (221, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 367);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (297, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 225);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (204, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 198);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (280, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 371);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (164, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 214);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (67, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 75);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (150, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 211);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (196, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 285);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (25, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 405);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (312, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 201);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (54, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 419);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (137, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 238);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (216, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 100);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (325, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 461);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (316, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 271);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (184, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 20);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (266, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 275);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (258, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 415);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (233, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 191);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (33, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 311);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (261, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 425);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (338, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 270);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (108, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 225);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (205, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 36);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (54, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 31);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (97, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 245);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (345, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 214);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (90, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 104);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (108, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 450);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (61, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 321);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (246, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 399);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (186, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 389);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (51, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 25);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (39, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 168);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (274, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 214);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (99, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 82);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (95, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 200);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (4, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 81);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (48, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 423);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (123, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 367);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (261, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 471);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (340, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 420);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (272, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 478);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (17, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 24);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (154, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 364);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (229, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 41);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (121, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 86);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (96, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 491);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (337, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 141);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (233, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 434);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (16, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 73);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (301, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 18);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (142, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 130);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (227, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 287);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (227, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 250);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (264, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 232);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (50, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 481);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (315, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 45);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (158, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 42);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (335, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 163);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (305, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 440);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (2, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 198);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (347, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 322);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (294, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 414);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (341, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 48);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (255, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 261);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (306, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 158);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (245, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 58);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (61, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 124);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (257, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 469);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (238, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 313);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (208, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 277);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (78, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 347);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (136, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 439);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (265, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 480);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (318, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 413);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (255, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 20);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (167, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 353);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (52, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 280);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (72, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 406);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (325, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 99);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (76, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 302);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (186, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 79);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (334, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 372);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (344, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 298);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (35, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 359);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (129, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 248);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (183, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 211);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (95, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 154);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (89, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 333);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (130, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 72);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (238, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 48);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (296, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 60);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (300, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 121);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (20, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 173);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (151, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 145);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (50, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 155);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (175, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 100);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (27, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 24);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (227, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 387);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (250, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 138);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (149, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 403);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (19, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 81);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (251, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 231);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (251, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 220);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (239, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 362);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (11, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 326);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (52, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 154);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (58, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 226);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (319, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 241);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (83, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 27);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (289, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 340);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (339, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 373);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (309, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 416);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (16, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 78);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (314, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 88);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (164, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 408);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (161, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 343);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (33, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 105);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (39, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 82);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (193, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 63);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (36, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 400);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (193, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 208);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (350, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 333);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (85, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 101);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (315, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 419);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (136, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 217);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (60, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 371);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (30, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 363);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (82, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 51);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (121, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 270);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (301, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 472);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (247, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 467);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (13, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 280);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (36, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 83);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (109, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 498);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (223, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 162);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (321, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 29);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (238, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 481);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (328, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 269);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (258, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 123);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (193, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 268);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (229, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 32);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (119, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 385);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (232, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 35);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (237, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 170);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (145, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 395);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (278, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 446);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (165, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 16);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (201, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 178);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (114, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 218);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (263, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 32);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (304, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 128);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (341, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 34);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (300, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 473);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (88, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 122);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (308, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 185);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (321, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 406);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (100, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 287);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (145, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 286);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (54, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 478);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (331, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 136);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (299, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 93);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (245, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 66);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (256, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 375);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (1, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 26);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (79, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 405);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (135, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 294);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (296, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 43);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (82, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 366);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (177, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 227);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (124, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 466);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (307, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 123);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (322, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 319);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (10, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 178);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (34, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 114);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (63, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 181);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (150, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 411);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (233, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 488);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (296, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 155);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (133, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 397);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (127, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 498);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (281, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 208);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (303, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 394);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (330, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 255);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (343, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 52);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (336, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 351);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (278, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 176);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (37, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 377);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (69, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 148);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (121, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 282);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (224, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 431);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (84, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 388);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (66, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 381);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (196, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 196);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (317, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 408);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (252, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 278);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (317, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 86);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (122, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 88);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (242, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 77);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (1, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 366);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (40, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 216);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (329, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 425);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (336, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 458);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (98, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 156);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (99, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 78);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (230, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 191);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (33, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 243);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (87, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 480);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (204, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 256);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (77, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 219);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (211, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 146);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (202, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 318);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (3, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 328);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (328, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 92);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (173, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 176);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (124, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 30);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (179, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 103);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (49, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 115);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (277, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 127);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (346, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 456);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (300, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 439);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (239, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 398);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (227, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 74);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (178, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 283);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (123, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 137);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (94, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 98);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (271, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 64);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (304, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 329);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (16, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 487);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (100, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 310);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (39, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 268);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (267, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 422);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (141, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 252);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (326, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 304);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (72, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 200);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (92, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 35);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (137, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 43);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (14, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 58);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (261, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 284);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (292, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 466);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (153, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 115);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (197, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 122);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (306, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 370);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (126, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 53);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (227, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 377);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (318, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 294);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (83, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 489);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (198, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 259);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (113, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 356);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (75, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 50);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (188, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 185);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (99, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 277);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (333, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 122);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (286, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 341);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (241, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 233);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (273, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 230);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (317, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 89);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (112, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 330);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (90, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 306);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (46, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 395);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (239, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 255);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (279, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 36);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (18, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 176);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (24, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 452);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (79, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 273);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (59, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 130);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (65, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 118);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (287, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 262);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (308, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 85);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (117, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 127);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (215, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 430);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (290, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 292);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (316, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 362);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (175, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 19);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (194, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 389);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (191, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 207);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (28, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 326);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (317, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 63);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (298, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 59);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (227, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 339);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (310, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 216);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (150, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 215);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (316, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 105);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (280, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 433);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (60, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 207);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (209, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 156);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (308, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 423);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (250, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 137);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (268, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 202);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (150, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 497);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (252, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 336);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (276, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 196);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (294, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 229);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (263, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 190);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (211, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 452);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (181, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 182);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (76, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 328);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (23, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 225);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (227, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 333);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (169, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 142);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (72, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 64);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (161, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 56);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (170, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 459);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (216, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 230);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (115, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 191);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (139, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 161);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (330, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 141);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (199, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 405);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (258, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 352);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (268, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 464);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (123, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 470);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (149, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 315);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (268, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 306);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (163, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 226);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (265, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 401);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (258, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 352);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (149, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 269);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (253, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 425);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (239, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 275);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (189, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 191);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (165, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 328);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (116, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 372);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (93, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 398);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (106, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 361);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (303, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 334);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (285, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 158);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (294, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 433);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (1, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 69);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (90, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 465);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (197, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 239);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (71, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 353);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (249, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 321);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (143, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 495);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (29, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 349);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (250, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 74);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (271, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 105);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (134, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 408);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (188, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 57);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (47, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 138);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (34, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 422);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (137, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 353);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (45, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 130);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (73, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 427);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (14, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 345);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (102, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 303);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (167, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 488);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (153, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 70);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (350, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 37);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (342, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 197);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (211, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 22);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (34, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 256);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (194, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 286);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (348, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 352);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (184, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 294);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (154, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 355);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (65, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 457);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (188, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 216);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (10, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 423);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (29, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 20);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (140, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 180);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (80, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 458);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (254, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 188);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (228, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 344);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (85, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 405);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (304, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 163);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (42, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 363);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (5, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 100);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (223, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 129);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (271, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 500);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (298, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 62);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (64, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 281);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (150, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 371);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (278, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 114);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (49, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 481);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (145, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 115);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (189, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 327);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (60, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 302);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (163, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 105);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (64, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 310);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (162, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 480);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (317, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 297);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (94, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 29);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (177, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 199);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (127, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 216);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (87, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 37);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (88, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 243);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (124, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 445);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (1, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 92);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (303, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 57);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (186, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 251);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (207, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 312);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (341, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 226);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (97, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 276);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (244, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 83);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (119, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 132);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (201, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 361);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (137, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 424);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (47, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 412);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (135, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 209);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (31, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 25);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (214, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 173);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (156, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 297);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (29, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 440);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (8, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 202);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (291, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 483);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (119, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 400);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (73, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 463);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (77, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 350);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (91, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 425);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (199, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 231);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (148, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 312);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (159, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 240);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (261, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 80);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (64, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 207);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (242, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 107);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (83, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 346);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (51, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 20);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (162, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 153);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (260, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 89);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (26, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 169);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (325, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 483);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (281, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 411);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (102, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 290);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (182, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 482);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (172, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 317);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (153, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 202);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (113, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 353);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (123, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 193);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (341, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 150);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (23, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 48);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (299, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 450);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (281, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 90);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (280, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 351);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (86, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 443);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (35, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 292);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (35, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 31);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (217, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 228);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (155, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 408);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (105, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 339);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (287, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 375);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (226, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 290);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (348, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 217);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (126, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 159);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (326, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 126);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (104, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 209);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (55, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 320);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (350, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 444);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (253, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 429);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (8, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 452);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (30, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 115);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (286, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 108);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (291, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 164);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (302, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18, 238);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (40, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 201);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (1, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 187);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (309, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 121);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (125, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 492);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (60, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 159);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (290, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 53);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (194, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 178);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (256, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 439);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (336, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 203);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (40, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 488);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (20, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 216);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (4, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 441);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (338, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 285);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (221, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 291);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (57, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 428);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (225, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 465);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (311, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 109);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (326, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 101);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (160, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 213);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (307, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 420);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (239, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 427);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (63, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 186);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (311, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 418);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (324, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 289);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (284, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 407);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (324, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 456);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (70, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 243);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (93, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 280);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (181, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 362);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (320, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 442);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (206, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 264);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (117, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 182);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (80, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 378);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (154, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 206);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (106, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 294);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (294, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 420);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (326, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 123);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (121, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 416);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (233, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 241);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (3, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 87);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (176, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 460);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (194, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 371);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (339, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 48);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (289, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13, 35);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (120, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8, 164);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (23, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 397);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (199, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 120);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (243, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 96);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (3, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 212);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (69, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 278);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (299, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 250);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (93, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20, 96);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (349, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 392);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (38, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5, 360);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (153, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 453);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (140, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 142);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (326, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 320);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (188, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 240);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (43, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 40);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (57, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16, 432);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (226, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2, 473);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (18, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 150);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (338, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19, 243);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (36, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10, 153);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (109, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 238);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (10, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9, 108);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (173, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6, 41);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (311, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 101);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (30, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7, 133);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (121, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 355);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (216, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14, 194);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (252, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17, 355);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (144, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15, 118);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (218, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12, 429);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (73, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4, 299);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (82, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11, 237);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (45, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3, 358);
INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (14, (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1, 228);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 17);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 10);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 9);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 23);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 20);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 22);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 21);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 6);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 7);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 25);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 8);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 16);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 24);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 5);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 2);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 11);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 15);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 12);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 1);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 14);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 3);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 18);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 4);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 19);
INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), 13);
COMMIT;
