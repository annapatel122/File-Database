<?php

$host="localhost";
$user="root";
$pwd="";
$db="superstore";

$conn = new mysqli($host, $user, $pwd, $db);

if ($conn->connect_error) { 
die ("Connection failed: " . $conn->connect_error);
}

// Generate SQL queries
$sql = "";

// Important SQL commands
$sql .= "USE superstore;\n";
$sql .= "SET AUTOCOMMIT=0;\n";
$sql .= "SET FOREIGN_KEY_CHECKS=0;\n";
$sql .= "SET GLOBAL FOREIGN_KEY_CHECKS=0;\n";







// Populate the "address" table
$validCities = array(
    array("New York", "NY"),
    array("Los Angeles", "CA"),
    array("Chicago", "IL"),
    array("Houston", "TX"),
    array("Philadelphia", "PA")
);

for ($i = 1; $i <= 150; $i++) {
    $streetNumber = rand(1, 9999);
    $streetName = array("Main St", "Broadway", "Park Ave", "5th Ave", "Elm St");
    $streetType = array("St", "Ave", "Blvd", "Dr", "Ln");
    $validCity = $validCities[array_rand($validCities)];
    $city = $validCity[0];
    $state = $validCity[1];
    $zip = rand(10000, 99999);
    $sql .= "INSERT IGNORE INTO address (address_id, street, city, state, zip)
             VALUES 
             ($i, '{$streetNumber} {$streetName[rand(0,4)]} {$streetType[rand(0,4)]}', '{$city}', '{$state}', '$zip');\n";
}





// Populate the "customer" table
for ($i = 1; $i <= 100; $i++) {
    $firstName = array("John", "Sarah", "Mike", "Linda", "David", "Emily", "Mark", "Lisa", "Steven", "Mary");
    $lastName = array("Smith", "Johnson", "Williams", "Jones", "Brown", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez");
    $phone = sprintf("(%d%d%d) %d%d%d-%d%d%d%d", rand(0, 9), rand(0, 9), rand(0, 9), rand(0, 9), rand(0, 9), rand(0, 9), rand(0, 9), rand(0, 9), rand(0, 9), rand(0, 9));
    $customerId = rand(100000, 999999) . $i;
    $sql .= "INSERT IGNORE INTO customer (customer_id, first_name, last_name, email, phone, address_id)
             VALUES 
             ('{$customerId}', '{$firstName[array_rand($firstName)]}', '{$lastName[array_rand($lastName)]}', 'customer{$i}@superstore.com', '{$phone}', " . rand(1, 150) . ");\n";
}




// Populate the "order" table
for ($i = 1; $i <= 350; $i++) {
    $orderId = rand(100000, 999999);
    $customerId = rand(1000, 9999);
    $addressId = rand(1, 150);
    $sql .= "INSERT IGNORE INTO `order` (order_id, customer_id, address_id)
             VALUES 
			 ('$orderId', '$customerId', '$addressId');\n";
}







// Populate the "product" table
$productID = 1; // Start with product ID of 1
for ($i = 1; $i <= 750; $i++) {
    $adjective = array("wonderful", "amazing", "fantastic", "spectacular", "brilliant");
    $noun = array("hammer", "laptop", "book", "chair", "table");
    $adjective2 = array("illustrious", "magnificent", "splendid", "gorgeous", "stunning");
    $color = array("blue", "green", "red", "yellow", "purple");
    $material = array("plastic", "metal", "wood", "glass", "ceramic");
    $verb = array("cutting", "drilling", "writing", "painting", "cooking");
    $selectedNoun = $noun[array_rand($noun)];
    $description = "A " . $adjective[rand(0,4)] . " " . $selectedNoun . " in an " . $adjective2[rand(0,4)] . " " . $color[rand(0,4)] . " made of " . $material[rand(0,4)] . " useful for " . $verb[rand(0,4)];
    $weight = rand(10, 500);
    $base_cost = rand(1, 4);
    $sql .= "INSERT INTO product (product_id, product_name, description, weight, base_cost) 
             SELECT $productID, '$selectedNoun', '$description', $weight, $base_cost
             FROM DUAL 
             WHERE NOT EXISTS (
                 SELECT * FROM product WHERE product_name = '$selectedNoun'
             ) AND NOT EXISTS (
                 SELECT * FROM product WHERE product_id = $productID
             );\n";
    $productID++; // Increment the product ID
}






// Populate the "warehouse" table
for ($i = 1; $i <= 25; $i++) {
    $warehouseID = rand(100,999);
	$addressID = rand(1000,9999);
	$names = array("Alpha Warehouse", "Beta Warehouse", "Gamma Warehouse", "Delta Warehouse", "Epsilon Warehouse");
	$warehouseName = $names[array_rand($names)];
	$sql .= "INSERT IGNORE INTO warehouse (warehouse_id, name, address_id)
             VALUES 
             ('$warehouseID', '$warehouseName', '$addressID');\n";
}





// Populate the "order_item" table
for ($i = 1; $i <= 550; $i++) {
    $sql .= "INSERT IGNORE INTO order_item (order_id, product_id, quantity, price)
             VALUES 
             (" . rand(1, 350) . ", (SELECT product_id FROM product ORDER BY RAND() LIMIT 1), " . rand(1, 20) . ", " . rand(15, 500) . ");\n";
}




// Populate the "product_warehouse" table
for ($i = 1; $i <= 1250; $i++) {
    $sql .= "INSERT IGNORE INTO product_warehouse (product_id, warehouse_id)
             VALUES 
             ((SELECT product_id FROM product ORDER BY RAND() LIMIT 1), " . rand(1, 25) . ");\n";
}




// Commit the changes
$sql .= "COMMIT;\n";


// Write SQL queries to file
$file = fopen("data.sql", "w");
fwrite($file, $sql);
fclose($file);

echo "Data generated successfully";




$conn->close();
?>
