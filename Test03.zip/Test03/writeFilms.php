<?php
include 'config.php';

// query the database to get movie titles, actor names, and count of actors for each movie
$sql = "SELECT f.title, COUNT(a.actor_id) AS actor_count, GROUP_CONCAT(CONCAT(a.first_name, ' ', a.last_name) SEPARATOR ',') AS actor_names
        FROM film f
        INNER JOIN film_actor fa ON f.film_id = fa.film_id
        INNER JOIN actor a ON fa.actor_id = a.actor_id
        GROUP BY f.film_id
        ORDER BY f.title";

$result = mysqli_query($conn, $sql);

// create and open the text file for writing
$file = fopen("movies.txt", "w");

// start the HTML table
echo "<table border=1>";
echo "<thead>";
echo 
"<tr>
<th>Title</th>
<th>Number of Actors</th>
<th>Actor Names</th>
</tr>";
echo "</thead>";
echo "<tbody>";

while($row = mysqli_fetch_assoc($result)) {
    // write to the text file
    $text = $row["title"] . ":" . $row["actor_count"] . ":" . $row["actor_names"] . ";";
    fwrite($file, $text . "\n");
    
    // output to the HTML table
    echo "<tr>";
    echo "<td>" . $row["title"] . "</td>";
    echo "<td>" . $row["actor_count"] . "</td>";
    echo "<td>" . $row["actor_names"] . "</td>";
    echo "</tr>";
}

// end the HTML table
echo "</tbody>";
echo "</table>";

// close the text file and the database connection
fclose($file);
mysqli_close($conn);
?>


